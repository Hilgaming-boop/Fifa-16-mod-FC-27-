-- Gerenciamento de Configuração de Torneios
-- Suporta múltiplos formatos: Group + Knockout, Knockout e League

local CustomCup = {}

do
    CustomCup.BND_TOURNAMENT_TYPE_LABEL = "bnd_tournament_type_toggle"
    CustomCup.BND_TOURNAMENT_TYPE_TEXT = "bnd_tournament_type_text"
    CustomCup.BND_TOURNAMENT_CREST = "bnd_tournament_crest"
    CustomCup.BND_PREV_TOURNAMENT_CREST = "bnd_prev_tournament_crest"
    CustomCup.BND_NEXT_TOURNAMENT_CREST = "bnd_next_tournament_crest"
    CustomCup.BND_TEAM_COUNT_LABEL = "bnd_number_of_teams_toggle"
    CustomCup.BND_TEAM_COUNT_TEXT = "bnd_team_count_text"
    CustomCup.BND_AUTO_FILL_LABEL = "bnd_auto_fills_toggle"
    CustomCup.BND_AUTO_FILL_TEXT = "bnd_auto_fill_text"
    CustomCup.BND_TEAM_GENDER_LABEL = "bnd_team_type_toggle"
    CustomCup.BND_TEAM_GENDER_TEXT = "bnd_team_type_text"
    CustomCup.BND_CUP_ID_LABEL = "bnd_tour_id_toggle"
    CustomCup.BND_CUP_ID_TEXT = "bnd_tour_id_text"
    CustomCup.BND_DESCRIPTION = "bnd_description"
    CustomCup.BND_TAB1_VISIBLE = "bnd_tab1_visible"
    CustomCup.BND_TAB2_VISIBLE = "bnd_tab2_visible"
    CustomCup.BND_TAB3_VISIBLE = "bnd_tab3_visible"
    CustomCup.BND_TAB4_VISIBLE = "bnd_tab4_visible"
    CustomCup.BND_TAB5_VISIBLE = "bnd_tab5_visible"

    CustomCup.ACT_NEXT_TOURNAMENT_TYPE = "act_next_tournament_type"
    CustomCup.ACT_PREV_TOURNAMENT_TYPE = "act_prev_tournament_type"
    CustomCup.ACT_NEXT_TEAM_COUNT = "act_next_team_count"
    CustomCup.ACT_PREV_TEAM_COUNT = "act_prev_team_count"
    CustomCup.ACT_NEXT_AUTO_FILL = "act_next_auto_fill"
    CustomCup.ACT_PREV_AUTO_FILL = "act_prev_auto_fill"
    CustomCup.ACT_NEXT_TEAM_GENDER = "act_next_team_gender"
    CustomCup.ACT_PREV_TEAM_GENDER = "act_prev_team_gender"
    CustomCup.ACT_NEXT_CUP_ID = "act_next_tour_id"
    CustomCup.ACT_PREV_CUP_ID = "act_prev_tour_id"
    CustomCup.ACT_CONFIRM_SETUP = "act_confirm_setup"
    CustomCup.ACT_BNT_CLICK = "act_btn_click"
    
    -- AKSI LOAD GAME
    CustomCup.ACT_LOAD_GAME = "act_load_game"
end

GlobalTournamentSettings = GlobalTournamentSettings or {}

-- Kamus penerjemah skor QWERTY
local SYMBOL_TO_SCORELINE = {
    ["q"]="0-0", ["w"]="1-0", ["e"]="2-0", ["r"]="3-0", ["t"]="4-0", ["y"]="5-0", ["u"]="6-0", ["i"]="7-0",
    ["o"]="1-1", ["p"]="2-2", ["a"]="3-3", ["s"]="4-4", ["d"]="5-5", ["f"]="0-1", ["g"]="0-2", ["h"]="0-3",
    ["j"]="0-4", ["k"]="0-5", ["@"]="0-6", ["z"]="0-7", ["x"]="2-1", ["c"]="3-1", ["v"]="4-1", ["b"]="5-1",
    ["n"]="6-1", ["m"]="7-1", ["Q"]="1-2", ["W"]="1-3", ["E"]="1-4", ["R"]="1-5", ["T"]="1-6", ["Y"]="1-7",
    ["U"]="3-2", ["*"]="4-2", ["O"]="5-2", ["P"]="6-2", ["A"]="7-2", ["S"]="4-3", ["D"]="5-3", ["F"]="6-3",
    ["G"]="7-3", ["H"]="5-4", ["K"]="2-3", ["L"]="2-4", ["Z"]="2-5", ["X"]="2-6", ["C"]="2-7", ["V"]="3-4",
    ["B"]="3-5", ["N"]="3-6", ["M"]="3-7", ["J"]="4-5"
}

function CustomCup:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self

    o.services = { settingsService = o.api("SettingsService") }
    
    -- Configurações de contagem de times por formato de torneio
    o.teamCountLists = {
        full = {
            { name = "8 Teams", value = 8 },
            { name = "16 Teams", value = 16 },
            { name = "24 Teams", value = 24 },
            { name = "32 Teams", value = 32 },
            { name = "48 Teams", value = 48 }
        },
        knockout = {
            { name = "8 Teams", value = 8 },
            { name = "16 Teams", value = 16 }
        },
        groupKnockoutOnly = {
            { name = "8 Teams", value = 8 },
            { name = "16 Teams", value = 16 },
            { name = "24 Teams", value = 24 },
            { name = "32 Teams", value = 32 },
            { name = "48 Teams", value = 48 }
        },
        league = {
            { name = "36 Teams", value = 36 }
        }
    }
    
    -- Todas as ligas disponíveis
    o.allTournaments = {    	        
        { name = "UEFA Champions League", value = 1, availableTeamCounts = {32} },
        { name = "FIFA World Cup 2026", value = 2, availableTeamCounts = {48} },
        { name = "UEFA Europa League", value = 3, availableTeamCounts = {32} },
        { name = "UEFA Conference League", value = 17, availableTeamCounts = {32} },
        { name = "FIFA Club World Cup", value = 15, availableTeamCounts = {32} },      
        { name = "Classic Tour", value = 22, availableTeamCounts = {32} },
        { name = "The Emirates FA Cup", value = 9, availableTeamCounts = {32} },
        { name = "Copa del Rey", value = 10, availableTeamCounts = {32} },
        { name = "Coppa Italia", value = 11, availableTeamCounts = {32} },
        { name = "Coupe de France", value = 18, availableTeamCounts = {32} },
        { name = "Dfb Pokal", value = 7, availableTeamCounts = {32} },
        { name = "Copa America", value = 25, availableTeamCounts = {32} },     
        { name = "Kratingdaeng Piala Indonesia", value = 29, availableTeamCounts = {32} },       
        { name = "AFC Champions League Elit", value = 24, availableTeamCounts = {32} },
        { name = "AFC Champions League Two", value = 31, availableTeamCounts = {32} },
        { name = "AFC Challenge League", value = 21, availableTeamCounts = {32} },
        { name = "CONMEBOL Libertadores", value = 4, availableTeamCounts = {32} },
        { name = "AFC Asian Cup Qatar 2023™", value = 34, availableTeamCounts = {16,24} },
        { name = "UEFA Euro", value = 6, availableTeamCounts = {16,24} },
        { name = "UEFA Nations League", value = 28, availableTeamCounts = {16,24} },
        { name = "US Open Tour", value = 13, availableTeamCounts = {16,24} },                
        { name = "Africa Cup Of Nations", value = 26, availableTeamCounts = {16,24} },
        { name = "ASEAN Hyundai Cup 2026", value = 27, availableTeamCounts = {8} },
        { name = "Piala Presiden", value = 32, availableTeamCounts = {8} },
        { name = "Sea Games U-23", value = 23, availableTeamCounts = {8} },
        { name = "Asean Shopee Cup", value = 12, availableTeamCounts = {8} },
        {name = "Saudi Arab Tour", value = 50, availableTeamCounts = {8} },
        { name = "UEFA Women CL", value = 16, availableTeamCounts = {8} },
        { name = "FIFA Women World Cup", value = 35, availableTeamCounts = {8} },    
        { name = "EA Sports Cup", value = 14, availableTeamCounts = {32} }   
    }
    
    o.options = {
        tournamentType = {
            { name = "Group + Knockout", value = 1 },
            { name = "Knockout", value = 2 },
            { name = "League", value = 3 }
        },
        teamCount = o.teamCountLists.full,
        autoFill  = { { name = "Yes", value = 1 }, { name = "No", value = 2 } },
        teamGender = { { name = "Men's Team", value = "Men" }, { name = "Women's Team", value = "Women" } },
        defaultTourIdList = {},
        leagueTourIdList = {}
    }
    
    o.options.tourId = {}
    o.options.menDefaultTours = {}
    o.options.womenDefaultTours = {}
    o.options.menLeagueTours = {}
    o.options.womenLeagueTours = {}
    
    -- Separa ligas por gênero (Women/Men)
    local womenKeywords = {"Women", "W World Tour", "Féminine", "Frauen-Bundesliga", "NWSL", "Liga F"}
    local function containsWomenKeyword(name)
        for _, keyword in ipairs(womenKeywords) do
            if string.find(name, keyword) then
                return true
            end
        end
        return false
    end

    for _, tour in ipairs(o.allTournaments) do
        if containsWomenKeyword(tour.name) then
            table.insert(o.options.womenDefaultTours, tour)
        else
            table.insert(o.options.menDefaultTours, tour)
        end
    end

    o.selectedIndices = {
        tournamentType = 1,
        teamCount = 2,
        autoFill = 1,
        teamGender = 1,
        tourId = 1
    }
    o.tournamentName = "Tournament"

    o:RegisterBindingsAndActions()
    o:PublishInitialData()
    
    o.tabBindings = { self.BND_TAB1_VISIBLE, self.BND_TAB2_VISIBLE, self.BND_TAB3_VISIBLE, self.BND_TAB4_VISIBLE, self.BND_TAB5_VISIBLE }
    for _, binding in ipairs(o.tabBindings) do
        o.im.Subscribe(binding, function() end)
    end
    o:HideSelections()
    o.im.Publish(self.BND_TAB1_VISIBLE, true)

    o.im.RegisterAction(self.ACT_BNT_CLICK, function(_, data)
        o:HideSelections()
        local tabIndex = data.buttonID + 1
        if o.tabBindings[tabIndex] then
            o.im.Publish(o.tabBindings[tabIndex], true)
        end
    end)
    
    return o
end

function CustomCup:RegisterBindingsAndActions()
    self.im.RegisterAction(self.ACT_NEXT_TOURNAMENT_TYPE, function() self:nextTournamentType() end)
    self.im.RegisterAction(self.ACT_PREV_TOURNAMENT_TYPE, function() self:prevTournamentType() end)
    self.im.Subscribe(self.BND_TOURNAMENT_TYPE_TEXT, function() self:updateTournamentTypeUI() end)
    self.im.Subscribe(self.BND_TOURNAMENT_CREST, function() self:updateTournamentTypeUI() end)
    self.im.Subscribe(self.BND_PREV_TOURNAMENT_CREST, function() self:updateTournamentTypeUI() end)
    self.im.Subscribe(self.BND_NEXT_TOURNAMENT_CREST, function() self:updateTournamentTypeUI() end)
    
    self.im.RegisterAction(self.ACT_NEXT_TEAM_COUNT, function() self:nextTeamCount() end)
    self.im.RegisterAction(self.ACT_PREV_TEAM_COUNT, function() self:prevTeamCount() end)
    self.im.Subscribe(self.BND_TEAM_COUNT_TEXT, function() self:updateTeamCountUI() end)

    self.im.RegisterAction(self.ACT_NEXT_AUTO_FILL, function() self:nextAutoFill() end)
    self.im.RegisterAction(self.ACT_PREV_AUTO_FILL, function() self:prevAutoFill() end)
    self.im.Subscribe(self.BND_AUTO_FILL_TEXT, function() self:updateAutoFillUI() end)
    
    self.im.RegisterAction(self.ACT_NEXT_TEAM_GENDER, function() self:nextTeamGender() end)
    self.im.RegisterAction(self.ACT_PREV_TEAM_GENDER, function() self:prevTeamGender() end)
    self.im.Subscribe(self.BND_TEAM_GENDER_TEXT, function() self:updateTeamGenderUI() end)
    
    self.im.RegisterAction(self.ACT_NEXT_CUP_ID, function() self:nexttourId() end)
    self.im.RegisterAction(self.ACT_PREV_CUP_ID, function() self:prevtourId() end)
    self.im.Subscribe(self.BND_CUP_ID_TEXT, function() self:updatetourIdUI() end)
    
    self.im.Subscribe(self.BND_DESCRIPTION, function() self:PublishDescription() end)
    self.im.RegisterAction(self.ACT_CONFIRM_SETUP, function() self:ConfirmAndProceed() end)
    
    -- DAFTARKAN ACT_LOAD_GAME
    self.im.RegisterAction(self.ACT_LOAD_GAME, function() self:LoadGameProcess() end)
end

function CustomCup:navigate(settingName, direction)
    local options = self.options[settingName]
    local currentIndex = self.selectedIndices[settingName]
    local newIndex = currentIndex + direction
    
    if newIndex > #options then newIndex = 1
    elseif newIndex < 1 then newIndex = #options end
    
    self.selectedIndices[settingName] = newIndex
end

function CustomCup:nextTournamentType() self:navigate("tournamentType", 1); self:updateTournamentTypeUI() end
function CustomCup:prevTournamentType() self:navigate("tournamentType", -1); self:updateTournamentTypeUI() end
function CustomCup:nextTeamCount() self:navigate("teamCount", 1); self:updateTeamCountUI() end
function CustomCup:prevTeamCount() self:navigate("teamCount", -1); self:updateTeamCountUI() end
function CustomCup:nexttourId() self:navigate("tourId", 1); self:updatetourIdUI() end
function CustomCup:prevtourId() self:navigate("tourId", -1); self:updatetourIdUI() end
function CustomCup:nextAutoFill() self:navigate("autoFill", 1); self:updateAutoFillUI() end
function CustomCup:prevAutoFill() self:navigate("autoFill", -1); self:updateAutoFillUI() end
function CustomCup:nextTeamGender() self:navigate("teamGender", 1); self:updateTeamGenderUI() end
function CustomCup:prevTeamGender() self:navigate("teamGender", -1); self:updateTeamGenderUI() end

-- Filtra torneios disponíveis por contagem de times e gênero
function CustomCup:getAvailableTournamentsForTeamCount(teamCount, gender)
    local baseTournaments = (gender == "Women") and self.options.womenDefaultTours or self.options.menDefaultTours
    local filteredTournaments = {}
    
    for _, tour in ipairs(baseTournaments) do
        for _, availableCount in ipairs(tour.availableTeamCounts) do
            if availableCount == teamCount then
                table.insert(filteredTournaments, tour)
                break
            end
        end
    end
    
    return filteredTournaments
end

function CustomCup:updateTournamentTypeUI()
    local options = self.options.tournamentType
    local totalOptions = #options
    local currentIndex = self.selectedIndices.tournamentType
    local currentOpt = options[currentIndex]
    if not currentOpt then return end

    -- Atualiza lista de times permitidos conforme tipo de torneio
    if currentOpt.name == "Group + Knockout" then
        self.options.teamCount = self.teamCountLists.groupKnockoutOnly
        self.selectedIndices.teamCount = 1
    elseif currentOpt.name == "Knockout" then
        self.options.teamCount = self.teamCountLists.knockout
        self.selectedIndices.teamCount = 1
    elseif currentOpt.name == "League" then
        self.options.teamCount = self.teamCountLists.league
        self.selectedIndices.teamCount = 1
    else
        self.options.teamCount = self.teamCountLists.full
        if self.selectedIndices.teamCount > #self.options.teamCount then
            self.selectedIndices.teamCount = #self.options.teamCount
        end
    end
    self:updateTourIdListBasedOnSelections()
    self:updateTeamCountUI()

    local prevIndex = (currentIndex - 2 + totalOptions) % totalOptions + 1
    local nextIndex = (currentIndex % totalOptions) + 1
    
    self.im.Publish(self.BND_TOURNAMENT_TYPE_LABEL, { data = {{ name = currentOpt.name }}, index = 0 })
    self.im.Publish(self.BND_TOURNAMENT_TYPE_TEXT, currentOpt.name)
    self.im.Publish(self.BND_TOURNAMENT_CREST, { name = "$Set_Cup", id = currentOpt.value })
    self.im.Publish(self.BND_PREV_TOURNAMENT_CREST, { name = "$Set_Cup", id = options[prevIndex].value })
    self.im.Publish(self.BND_NEXT_TOURNAMENT_CREST, { name = "$Set_Cup", id = options[nextIndex].value })
    
    self:PublishDescription()
end

function CustomCup:updateTourIdListBasedOnSelections()
    local typeOpt = self.options.tournamentType[self.selectedIndices.tournamentType]
    local genderOpt = self.options.teamGender[self.selectedIndices.teamGender]
    local teamCountOpt = self.options.teamCount[self.selectedIndices.teamCount]
    
    local teamCount = teamCountOpt and teamCountOpt.value or 16

    -- Filtra torneios de acordo com contagem de times e gênero
    if typeOpt.name == "League" then
        self.options.tourId = self:getAvailableTournamentsForTeamCount(teamCount, genderOpt.value)
    else
        self.options.tourId = self:getAvailableTournamentsForTeamCount(teamCount, genderOpt.value)
    end
    
    self.selectedIndices.tourId = 1
    self:updatetourIdUI()
end

function CustomCup:updateTeamCountUI()
    local current = self.options.teamCount[self.selectedIndices.teamCount]
    if current then
        self.im.Publish(self.BND_TEAM_COUNT_TEXT, current.name)
        self:updateTourIdListBasedOnSelections()
        self:PublishDescription()
    end
end

function CustomCup:updateAutoFillUI()
    local current = self.options.autoFill[self.selectedIndices.autoFill]
    if current then
        self.im.Publish(self.BND_AUTO_FILL_LABEL, { data = {{ name = current.name }}, index = 0 })
        self.im.Publish(self.BND_AUTO_FILL_TEXT, current.name)
        self:PublishDescription()
    end
end

function CustomCup:updatetourIdUI()
    local current = self.options.tourId[self.selectedIndices.tourId]
    if current then
        self.im.Publish(self.BND_CUP_ID_TEXT, current.name)
        self:PublishDescription()
    end
end

function CustomCup:updateTeamGenderUI()
    local current = self.options.teamGender[self.selectedIndices.teamGender]
    if current then
        self.im.Publish(self.BND_TEAM_GENDER_LABEL, { data = {{ name = current.name }}, index = 0 })
        self.im.Publish(self.BND_TEAM_GENDER_TEXT, current.name)
        self:updateTourIdListBasedOnSelections()
        self:PublishDescription()
    end
end

function CustomCup:PublishInitialData()
    self:updateTournamentTypeUI()
    self:updateTeamCountUI()
    self:updateAutoFillUI()
    self:updatetourIdUI()
    self:updateTeamGenderUI()
end

function CustomCup:PublishDescription()
    local typeOpt = self.options.tournamentType[self.selectedIndices.tournamentType]
    local teamsOpt = self.options.teamCount[self.selectedIndices.teamCount]
    local tourOpt = self.options.tourId[self.selectedIndices.tourId]
    local genderOpt = self.options.teamGender[self.selectedIndices.teamGender]

    if typeOpt and teamsOpt and tourOpt and genderOpt then
        local desc = string.format(
            "You are creating a %s tournament named '%s' with %s %s teams, featuring the %s branding.",
            string.upper(typeOpt.name),
            self.tournamentName,
            teamsOpt.name,
            genderOpt.name,
            tourOpt.name
        )
        self.im.Publish(self.BND_DESCRIPTION, desc)
    end
end

function CustomCup:ConfirmAndProceed()
    local selectedTourId = self.options.tourId[self.selectedIndices.tourId].value
    local selectedTeamCount = self.options.teamCount[self.selectedIndices.teamCount].value
    local selectedTournamentType = self.options.tournamentType[self.selectedIndices.tournamentType].name

    local totalGroups = 0
    local teamsPerGroup = 4
    local isKnockoutOnly = false
    local matchdaysPerGroup = 0
    local isLeagueMode = false
    
    if selectedTournamentType == "League" then
        isLeagueMode = true
        totalGroups = 1
        teamsPerGroup = 36
        matchdaysPerGroup = 0
    elseif selectedTournamentType == "Knockout" then
        isKnockoutOnly = true
        totalGroups = 0
        matchdaysPerGroup = 0
    elseif selectedTeamCount == 8 then
        totalGroups = 2
        matchdaysPerGroup = 3
    elseif selectedTeamCount == 16 then
        totalGroups = 4
        matchdaysPerGroup = 3
    elseif selectedTeamCount == 24 then
        totalGroups = 6
        matchdaysPerGroup = 3
    elseif selectedTeamCount == 32 then
        totalGroups = 8
        matchdaysPerGroup = 6
    elseif selectedTeamCount == 48 then
        totalGroups = 12
        matchdaysPerGroup = 3
    end
    
    GlobalTournamentSettings = {
        tourId = selectedTourId,
        teamCount = selectedTeamCount,
        tournamentType = selectedTournamentType,
        tournamentName = self.tournamentName,
        selectedTourId = selectedTourId,
        teamsPerGroup = teamsPerGroup,
        totalGroups = totalGroups,
        isKnockoutOnly = isKnockoutOnly,
        matchdaysPerGroup = matchdaysPerGroup,
        isLeagueMode = isLeagueMode,
        useUCLStyle = (selectedTournamentType == "Group + Knockout"),
        isLoadedGame = false
    }

    self.nav.Event(nil, "evt_group_stage")
end

-- PROSES LOAD GAME LENGKAP (SKOR + TOP SCORE / GOALS AKURAT)
function CustomCup:LoadGameProcess()
    print("[CustomCup] Memuat data save lengkap dengan skor dan top scorer...")
    
    local rawSaveString = "<Version>v1</Version>|<Status>complete</Status>|<TourID>2</TourID>|<TeamID>1369</TeamID>|<TournamentType>Group   Knockout</TournamentType>|<Results>OxEUwdsWLdVxVL*cwdxxVocKjBWyVSrsKVoQVyvtVHQvkdcRdfeqkZOBhvdwpWpROdevKedQWUqKxLEw*QjKQhex</Results>|<Goals>75145:1;75209:2;259197:1;211738:0;262638:1;253257:2;198133:1;261050:1;256196:1;246104:1;76232:1;218191:1;216275:1;251854:1;231478:2;235183:0;277846:1;236461:1;270821:0;92713:1;193474:3;266096:1;242914:1;256903:1;241637:1;274913:1;220814:1;212830:1;85688:1;274915:1;235634:1;262396:1;242916:1;262652:1;235890:1;217047:1;248793:1;268913:1;230142:1;264698:1;231867:4;252371:2;253010:1;81346:1;74735:1;81410:1;260740:1;231677:1;251223:2;217050:1;237043:1;226376:1;245539:2;228229:1;247264:1;233084:1;257293:1;207790:1;74449:1;241197:1;220821:1;245541:1;273651:1;74705:2;237238:2;244456:1;183711:1;241710:1;277742:1;414307:1;266245:1;71161:2;63015:3;202556:1;255253:2;255956:1;243245:1;201024:2;62664:0;246696:2;71418:1;220380:1;236541:1;76784:1;233731:1;256790:1;244654:0;252383:1;246826:2;252064:1;241461:1;62681:1;84610:1;167495:0;63879:1;222875:2;254685:1;253727:1;211378:1;207993:1;247468:2;212401:1;233927:1;213615:0;254623:2;80236:1;241721:1;200458:1;262098:1;239231:1;222560:1;61405:1;209658:1;263205:1;246195:1;265761:3;204485:1;199439:1;227928:1;267680:1;258908:1;263976:0;86243:0;237255:1;262039:1;257568:0;248498:1;255205:1;77972:1;230869:0;256675:3;257889:1;80304:1;253163:1;241602:1;254952:1;245371:1;276249:1;235790:1;235407:1;72640:1;231447:1;244797:1;276634:1;186352:1;60018:2;225316:1;210881:1;64234:1;191655:0;213884:1;255339:1;242948:0;278046:1;243715:2;266039:1;252416:1;243780:1;222382:1;232829:2;234579:1;235353:1;239085:3;245158:2;192119:0;234072:1;276646:1;181458:2;432418:1;243526:3;268982:1;234236:1;262595:1;247851:1;202089:0;212228:1;252873:1;188335:1;270039:1;244270:1;274447:1;180930:1;220375:1;198710:2;217620:1;197445:1;224258:1;247611:0;207439:1;233053:2;61601:0;260952:1;220820:0;253238:1;233884:1;64236:1;263112:1;219914:1;61729:1;242380:1;192366:1;73348:2;276144:1;251377:1;63876:1;255125:2;248148:1;216320:2;226093:1;254262:1;214979:0;260745:2;206566:0;433918:1;254143:1;228182:0;16916:0;71305:1;255566:1;268611:1;60548:1;220793:1;200155:1;254136:2;264652:1;202371:1;224179:1;257400:1;82899:1;251810:1;263376:1;242179:0;208722:1;259565:3;270531:2;74436:1;241171:1;234396:1;222492:2;236764:2;205452:1;262740:1;225203:0;236703:1;233510:1;250917:1;229476:1;263432:1;176550:0;273843:2;277178:1;214026:1;241173:3;241671:0;235662:2;256079:2;247050:2;62673:2;64222:2;235456:2;237086:1;228093:1;61731:2;273666:1;242195:1;261084:1;248712:1;228336:1;232999:1;238900:1;61407:1;254142:1;252162:1;200104:2;246669:1;204923:2;247819:1;190871:1;240925:1;16981:1;216393:1;200145:1;231416:1;215316:0;263922:0;210822:2;235173:1;271417:1;246618:4;239964:3;192505:4;60014:1;257345:1;241486:1;216267:1;227573:1;225964:1;246608:1;252293:1;273106:1;192123:1;252198:1;216218:1;202024:2;259307:1;243702:1;255360:1;222429:1;212516:2;246231:1;63010:1;246688:1;233260:1;67963:2;60008:0;239837:1;432415:1;250954:1;253385:2;257784:1;242970:1;211999:1;241943:1;257470:1;237721:2;263182:1;433907:0;258575:1;278688:1;258171:1;434075:1;204838:1;269278:1;261176:1;191043:1;247279:1;232839:1</Goals>|<GroupStandings>true</GroupStandings>"
    
    local savedData = {}
    if rawSaveString and rawSaveString ~= "" then
        for key, val in string.gmatch(rawSaveString, "<([^>]+)>([^<]*)</%1>") do
            savedData[key] = val:gsub("^%s+", ""):gsub("%s+$", "")
        end
        
        if not savedData.TourID then
            savedData.TourID = rawSaveString:match("<TourID>(.-)</TourID>")
            savedData.TeamID = rawSaveString:match("<TeamID>(.-)</TeamID>")
            savedData.TournamentType = rawSaveString:match("<TournamentType>(.-)</TournamentType>")
            savedData.Results = rawSaveString:match("<Results>(.-)</Results>")
            savedData.Goals = rawSaveString:match("<Goals>(.-)</Goals>")
        end
        
        if savedData.TourID then
            local tourId = tonumber(savedData.TourID) or 2
            local teamId = tonumber(savedData.TeamID) or 1369
            
            -- 1. Set Global Settings Turnamen World Cup 2026
            GlobalTournamentSettings = {
                tourId = tourId,
                teamCount = 48,
                tournamentType = savedData.TournamentType or "Group + Knockout",
                tournamentName = "FIFA WORLD CUP 2026",
                selectedTourId = tourId,
                teamsPerGroup = 4,
                totalGroups = 12,
                isKnockoutOnly = false,
                matchdaysPerGroup = 3,
                isLeagueMode = false,
                useUCLStyle = true,
                isLoadedGame = true
            }
            
            -- 2. Kunci Tim Pilihan Utama
            currentTourInfo = currentTourInfo or {}
            currentTourInfo[tourId] = {
                tourIndex = tourId,
                homeID = teamId,
                stage = "GROUP",
                isKnockoutOnly = false,
                isLeagueMode = false
            }
            
            -- 3.Database Tim Peserta World Cup 2026 (48 Tim)
            local TeamDatabase = {
                [2] = { 1386, 111099, 974, 1330, 111455, 105013, 111527, 1364, 1370, 111111, 112048, 1359, 1387, 1375, 1415, 1365, 1337, 112054, 111112, 111465, 105035, 1411, 1363, 1391, 1354, 1325, 111130, 1369, 111473, 1362, 111456, 111114, 1377, 1335, 1667, 111512, 1352, 111448, 1322, 111513, 111545, 111485, 111109, 1318, 1328, 111462, 111475, 111510 }
            }
            
            local potentialTeams = TeamDatabase[tourId] or TeamDatabase[2]
            local groupList = {}
            local totalGroups = 12
            local teamsPerGroup = 4
            
            for g = 1, totalGroups do
                groupList[g] = {}
                for i = 1, teamsPerGroup do
                    local index = (g - 1) * teamsPerGroup + i
                    if potentialTeams[index] then
                        table.insert(groupList[g], potentialTeams[index])
                    end
                end
            end
            
            -- 4. Bangun Jadwal Pertandingan Stabil
            QuickTourGrouping = QuickTourGrouping or {}
            QuickTourGrouping[tourId] = {}
            
            local groupSchedules = {}
            for gIndex, group in ipairs(groupList) do
                local schedule = {}
                for i = 1, #group do
                    for j = i + 1, #group do
                        table.insert(schedule, {group[i], group[j]})
                    end
                end
                groupSchedules[gIndex] = schedule
            end
            
            local fixtureList = {}
            for md = 1, 3 do
                for gIndex = 1, totalGroups do
                    local schedule = groupSchedules[gIndex]
                    local groupLetter = string.char(64 + gIndex)
                    local startIdx = (md - 1) * 2 + 1
                    for offset = 0, 1 do
                        local matchIdx = startIdx + offset
                        if schedule[matchIdx] then
                            local matchPair = schedule[matchIdx]
                            if matchPair[1] ~= matchPair[2] then
                                table.insert(fixtureList, { matchPair[1], matchPair[2], 0, 0, false, 0, false, true, groupLetter, md })
                            end
                        end
                    end
                end
            end
            
            QuickTourGrouping[tourId] = fixtureList
            
            -- 5. Inisialisasi Klasemen Awal
            GroupStandings = GroupStandings or {}
            GroupStandings[tourId] = {}
            for gIndex, group in ipairs(groupList) do
                local groupLetter = string.char(64 + gIndex)
                GroupStandings[tourId][groupLetter] = {}
                for _, tId in ipairs(group) do
                    GroupStandings[tourId][groupLetter][tId] = { teamId = tId, played = 0, win = 0, draw = 0, loss = 0, goalsFor = 0, goalsAgainst = 0, points = 0 }
                end
            end
            
            -- 6. Injeksi Skor & Status Selesai dari String Results
            if savedData.Results and QuickTourGrouping[tourId] then
                local resStr = savedData.Results
                for i = 1, #resStr do
                    local match = QuickTourGrouping[tourId][i]
                    if match then
                        local char = resStr:sub(i, i)
                        local scoreLine = SYMBOL_TO_SCORELINE[char]
                        if scoreLine then
                            local hGoals, aGoals = scoreLine:match("(%d+)-(%d+)")
                            hGoals, aGoals = tonumber(hGoals) or 0, tonumber(aGoals) or 0
                            
                            -- Jika ada skor tanding yang terekam (tidak kosong/bukan q default)
                            if char ~= "q" then
                                match[3] = hGoals
                                match[4] = aGoals
                                match[5] = true
                                match[6] = (hGoals > aGoals) and match[1] or (aGoals > hGoals) and match[2] or 0
                                
                                local gLetter = match[9]
                                local tHome, tAway = match[1], match[2]
                                if GroupStandings[tourId][gLetter] then
                                    local stH = GroupStandings[tourId][gLetter][tHome]
                                    local stA = GroupStandings[tourId][gLetter][tAway]
                                    if stH and stA then
                                        stH.played = stH.played + 1; stA.played = stA.played + 1
                                        stH.goalsFor = stH.goalsFor + hGoals; stH.goalsAgainst = stH.goalsAgainst + aGoals
                                        stA.goalsFor = stA.goalsFor + aGoals; stA.goalsAgainst = stA.goalsAgainst + hGoals
                                        if hGoals > aGoals then
                                            stH.win = stH.win + 1; stH.points = stH.points + 3; stA.loss = stA.loss + 1
                                        elseif hGoals < aGoals then
                                            stA.win = stA.win + 1; stA.points = stA.points + 3; stH.loss = stH.loss + 1
                                        else
                                            stH.draw = stH.draw + 1; stH.points = stH.points + 1
                                            stA.draw = stA.draw + 1; stA.points = stA.points + 1
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                print("[CustomCup] Injeksi skor pertandingan berhasil!")
            end
            
            -- 7. PEMULIHAN DATA TOP SCORE (GOALS) DARI STRING SAVE
            TournamentStats = TournamentStats or {}
            TournamentStats[tourId] = TournamentStats[tourId] or { Goals = {}, Assists = {}, Appearances = {}, YellowCards = {}, RedCards = {} }
            
            if savedData.Goals and savedData.Goals ~= "" and savedData.Goals ~= "none" then
                -- Format data gol di save: "cardID:jumlahGol;cardID:jumlahGol"
                for cardID, goals in string.gmatch(savedData.Goals, "([^;:]+):([^;:]+)") do
                    local cID = tonumber(cardID) or cardID
                    local gCount = tonumber(goals) or 0
                    if cID and gCount > 0 then
                        TournamentStats[tourId].Goals[cID] = gCount
                    end
                end
                print("[CustomCup] Data Top Scorer berhasil dipulihkan ke memori game!")
            end
            
            -- 8. Masuk ke Hub Turnamen
            self.nav.Event(nil, "evt_group_stage")
            return
        end
    end
    print("[CustomCup] Gagal memuat save!")
end



function CustomCup:HideSelections()
    for _, binding in ipairs(self.tabBindings or {}) do
        self.im.Publish(binding, false)
    end
end

function CustomCup:finalize()
    local actions = {
        self.ACT_NEXT_TOURNAMENT_TYPE, self.ACT_PREV_TOURNAMENT_TYPE,
        self.ACT_NEXT_TEAM_COUNT, self.ACT_PREV_TEAM_COUNT,
        self.ACT_NEXT_AUTO_FILL, self.ACT_PREV_AUTO_FILL,
        self.ACT_NEXT_CUP_ID, self.ACT_PREV_CUP_ID,
        self.ACT_NEXT_TEAM_GENDER, self.ACT_PREV_TEAM_GENDER,
        self.ACT_CONFIRM_SETUP, self.ACT_BNT_CLICK,
        self.ACT_LOAD_GAME
    }
    for _, action in ipairs(actions) do
        self.im.UnregisterAction(action)
    end

    local subscriptions = {
        self.BND_TOURNAMENT_TYPE_LABEL, self.BND_TOURNAMENT_TYPE_TEXT,
        self.BND_TOURNAMENT_CREST, self.BND_PREV_TOURNAMENT_CREST, self.BND_NEXT_TOURNAMENT_CREST,
        self.BND_TEAM_COUNT_LABEL, self.BND_TEAM_COUNT_TEXT,
        self.BND_AUTO_FILL_LABEL, self.BND_AUTO_FILL_TEXT,
        self.BND_CUP_ID_LABEL, self.BND_CUP_ID_TEXT,
        self.BND_TEAM_GENDER_LABEL, self.BND_TEAM_GENDER_TEXT,
        self.BND_DESCRIPTION,
        self.BND_TAB1_VISIBLE, self.BND_TAB2_VISIBLE, self.BND_TAB3_VISIBLE,
        self.BND_TAB4_VISIBLE, self.BND_TAB5_VISIBLE
    }
    for _, sub in ipairs(subscriptions) do
        self.im.Unsubscribe(sub)
    end
end

return CustomCup
