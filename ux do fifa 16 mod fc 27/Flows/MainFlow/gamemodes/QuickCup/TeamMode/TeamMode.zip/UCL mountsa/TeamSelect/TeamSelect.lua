--- IMPROVED TEAM SELECT BY MOUNTSA ---
local TeamSelect = {}
local NUM_TABS = 16
local MIN_TEAMS_FOR_CUP = 32
local MAX_TEAMS_FOR_CUP = 32
local DEFAULT_FLAG_ID = 0
for i = 1, 16 do
    _G["BND_TAB" .. i .. "_VISIBLE"] = "bnd_tab" .. i .. "_visible"
end
for i = 1, 16 do
  _G["TAB" .. i] = i
end
local BND_TEAM_RATING = "bnd_team_rating"
local bndTeamList = "bnd_team_list"
local BND_BG_CUP = "bnd_cup_bg"
local ACT_TEAM_SELECT = "act_team_select"
local ACT_CONFIRM = "act_confirm"
local ACT_selected = "act_selected"
local ACT_RANDOM = "act_random"

local OriginalTeamList = {
  1, 2, 10, 69, 39, 240, 32, 189, 22, 900, 78, 231, 101078, 211, 241, 21,
  246, 110062, 44, 45, 9, 65, 10, 47, 73, 247, 112172, 191, 243, 101059,
  209, 100810, 234, 267, 237, 378, 36
}

local fixedTeams = {
  9, 241, 1, 44, 240, 47, 39, 32,
  2, 69, 246, 65, 378, 22, 21, 243
}

local TEAM_FLAG_ID = {
  [9] = 14, [241] = 45, [1] = 14, [44] = 27, 
  [240] = 45, [47] = 27, [39] = 27,
  [32] = 21, [2] = 14, [69] = 18,
  [246] = 34, [65] = 18, [378] = 18,
  [22] = 21, [21] = 21, [243] = 45,
  [10] = 14, [45] = 27, [73] = 18,
  [78] = 14, [189] = 21, [211] = 45,
  [231] = 45, [234] = 45, [237] = 45,
  [247] = 18, [267] = 18, [900] = 21,
  [101059] = 45, [101078] = 45, [110062] = 14,
  [112172] = 18, [191] = 45, [209] = 45,
  [100810] = 18, [36] = 21
}
local filteredList = {}
for _, id in ipairs(OriginalTeamList) do
  local isUsed = false
  for _, fixed in ipairs(fixedTeams) do
    if id == fixed then
      isUsed = true
      break
    end
  end
  if not isUsed then
    table.insert(filteredList, id)
  end
end
local function shuffleArray(array)
  local n = #array
  for i = n, 2, -1 do
    local j = math.random(i)
    array[i], array[j] = array[j], array[i]
  end
end

shuffleArray(OriginalTeamList)

TeamList = {}
for i = 1, 32 do
  table.insert(TeamList,OriginalTeamList[i])
end

local currentTab = TAB1

cupId = 1

function TeamSelect:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  
  o.services = {
    SaveLoadService = o.api("SaveLoadService"),
    CountryService = o.api("CountryService"),
    EventManagerService = o.api("EventManagerService"),
    SquadManagementService = o.api("SquadMgtService")
  }
  
  o.tabTeams = {
    [TAB1] = {9}, [TAB2] = {241}, [TAB3] = {1},   [TAB4] = {44},
    [TAB5] = {240}, [TAB6] = {47}, [TAB7] = {39}, [TAB8] = {32},
    [TAB9] = {2},  [TAB10] = {69}, [TAB11] = {246}, [TAB12] = {65},
    [TAB13] = {378}, [TAB14] = {22}, [TAB15] = {21}, [TAB16] = {243}
  }
  
  o.cupData = {
    cupBg = {
      name = "$Bg_Cup",
      id = cupId
    }
  }
  
  currentCupInfo[cupId] = nil
  QuickCupGrouping[cupId] = nil

  if currentCupInfo[cupId] == nil then
    currentCupInfo[cupId] = { cupIndex = cupId, homeID = 0, awayID = 0 }
  end

  if currentCupInfo[cupId].homeID == 0 and o.services.StorageService then
    local savedId = o.services.StorageService.GetInt("last_selected_team_id") or 0
    if savedId ~= 0 then
      currentCupInfo[cupId].homeID = savedId
    end
  end

  if currentCupInfo[cupId].homeID ~= 0 then
    o.nav.Event(nil, "evt_team_select")
  else
    o:InitGrouping()
    o.im.Subscribe(bndTeamList, function()
      o:publishTeamRows()
    end)
    
    o.im.RegisterAction(ACT_TEAM_SELECT, function(actionName, data)
      if data then
        o:StartQuickCup(data)
      end
    end)
    
    o.im.RegisterAction(ACT_CONFIRM, function(actionName, data)
      if data then
        o:StartQuickCup(data)
      end
    end)
  end
  
  o.handlerId = o.services.EventManagerService.RegisterHandler(function(...)
    o:handleEvent(...)
  end)
  
  o.currentCountryID = -1
  o.buttonsID = {}

  for i = 1, 16 do
    table.insert(o.buttonsID, i)
    o.im.Subscribe("bnd_tab" .. i .. "_visible", function() end)
  end
  
  o.im.Subscribe("bnd_cup_bg", function()
    o.im.Publish("bnd_cup_bg", o.cupData.cupBg)
  end)
  
  o.im.RegisterAction(ACT_selected, function(actionName, data)
    o:HideSelections()
    currentTab = o.buttonsID[data.buttonID + 1]
    o.im.Publish("bnd_tab"..currentTab.."_visible", true)
    o:Init(currentTab)
    o:InitGrouping()
    o.selectedTeamIndex = nil
    o:publishTeamRating()
    o:publishTeamRows()
  end)

  o.im.RegisterAction(ACT_RANDOM, function(actionName, data)
    o:RandomizeTeams()
  end)

  o.teamObjects = {}
  local initialTeamIds = {
    9, 241, 1, 44,
    240, 47, 39, 32,
    2, 69, 246, 65,
    378, 22, 21, 243
  }

  for i, id in ipairs(initialTeamIds) do
    o.teamObjects[i] = {
      name = "$Crest",
      id = id
    }
  end
    
  for i = 1, 16 do
    local key = "bnd_team" .. i
    o.im.Subscribe(key, function()
      o.im.Publish(key, o.teamObjects[i])
    end)
  end
  
  o.im.Subscribe(BND_TEAM_RATING, function()
    o:publishTeamRating()
  end)
  
  return o
end

function TeamSelect:RandomizeTeams()

  local allTeams = {}
  for _, teamId in ipairs(fixedTeams) do
    table.insert(allTeams, teamId)
  end
  for _, teamId in ipairs(filteredList) do
    table.insert(allTeams, teamId)
  end
  
  math.randomseed(os.time())
  for i = #allTeams, 2, -1 do
    local j = math.random(i)
    allTeams[i], allTeams[j] = allTeams[j], allTeams[i]
  end
  
  local selectedTeams = {}
  for i = 1, 16 do
    if allTeams[i] then
      table.insert(selectedTeams, allTeams[i])
    end
  end
  
  for tabIndex = 1, 16 do
    if selectedTeams[tabIndex] then
      self.tabTeams[tabIndex] = {selectedTeams[tabIndex]}
    end
  end
  
  for i = 1, 16 do
    if selectedTeams[i] then
      self.teamObjects[i] = {
        name = "$Crest",
        id = selectedTeams[i]
      }
    end
  end
  
  for i = 1, 16 do
    self.im.Publish("bnd_team" .. i, self.teamObjects[i])
  end
  
  self:Init(currentTab)
  self:publishTeamRating()
  self:publishTeamRows()
  
  self:InitGrouping()
end

function TeamSelect:getFlagIdByTeamId(teamId)
  if self.services.CountryService and self.services.CountryService.GetFlagIdByTeamId then
    return self.services.CountryService.GetFlagIdByTeamId(teamId) or 0
  end
  return 0 
end

function TeamSelect:Init(tabID)
    TeamListData = {} 
    local teamsForTab = self.tabTeams[tabID] or self.tabTeams[TAB1]
    
    for i, teamId in ipairs(teamsForTab) do
        local teamInfo = self.services.SquadManagementService.GetTeamInfo(teamId) or {}
        local obj = {
            assetId = teamId,
            clickAction = "act_team_select",
            teamName = self.loc.LocalizeString("TeamName_Abbr15_"..teamId),
            shortTeamName = self.loc.LocalizeString("TeamName_Abbr3_"..teamId),
            ratingLabel = string.format("%.1f", teamInfo.starRating or 0),
            data = {
                TeamCrest = { name = "$Crest", id = teamId },
                flagCrest = { name = "$Flag128x128", id = TEAM_FLAG_ID[teamId] or 0 },
                TeamName = self.loc.LocalizeString("TeamName_Abbr15_"..teamId),
                Rating = teamInfo.starRating or 0,
                clickAction = "act_team_select",
                FontColor = "0xffffff",
                TeamNameFontColor = "0xffffff",
                Icon = { name = "$IconMatchBall", id = 2 }
            },
            rating = teamInfo.starRating or 0,
            offense = teamInfo.offense or 0,
            midfield = teamInfo.midfield or 0,
            defense = teamInfo.defense or 0
        }
        table.insert(TeamListData, obj)
    end
end

function TeamSelect:InitGrouping()
  currentCupInfo[cupId] = {
    cupIndex = cupId,
    homeID = 0
  }
  local groupingList = {}
  for i = 1, table.getn(TeamList) do
    local temp = i * 2 - 1
    if temp < #TeamList then
      table.insert(groupingList, {
        [1] = TeamList[temp],
        [2] = TeamList[temp+1],
        [3] = "0",
        [4] = "0",
        [5] = false,
        [6] = 0,
        [7] = false
      })
    end
  end
  QuickCupGrouping[cupId] = groupingList
end

function TeamSelect:publishTeamRating()
  local displayIndex = self.selectedTeamIndex or 1
  if not TeamListData or not TeamListData[displayIndex] then
    self.im.Publish(BND_TEAM_RATING, self:createEmptyRating())
    return
  end
  local teamData = TeamListData[displayIndex]
  local teamRating = {
    attackValue = math.floor(teamData.offense or 0),
    middleValue = math.floor(teamData.midfield or 0),
    defenseValue = math.floor(teamData.defense or 0),
    attackLabel = self.loc.LocalizeString("LTXT_CMN_ATT"),
    middleLabel = self.loc.LocalizeString("LTXT_CMN_MID"),
    defenseLabel = self.loc.LocalizeString("LTXT_CMN_DEF"),
    overallRating = string.format("%.1f", teamData.rating or 0),
    teamName = teamData.teamName or ""
  }
  
  self.im.Publish(BND_TEAM_RATING, teamRating)
end

function TeamSelect:createEmptyRating()
    return {
        attackValue = 0,
        middleValue = 0,
        defenseValue = 0,
        attackLabel = self.loc.LocalizeString("LTXT_CMN_ATT"),
        middleLabel = self.loc.LocalizeString("LTXT_CMN_MID"),
        defenseLabel = self.loc.LocalizeString("LTXT_CMN_DEF"),
        overallRating = "0.0",
        teamName = ""
    }
end

function TeamSelect:publishTeamRows()
  for i, v in ipairs(TeamListData) do
    local teamId = v.assetId
    local flagId = TEAM_FLAG_ID[teamId] or 0

    v.data.TeamCrest = {
      name = "$Crest",
      id = teamId
    }

    v.data.flagCrest = {
      name = "$Flag128x128",
      id = flagId
    }

    v.data.TeamName = v.teamName
    v.data.Rating = TeamListData[i].rating 
    v.data.clickAction = v.clickAction
    v.data.FontColor = "0xffffff"
    v.data.TeamNameFontColor = "0xffffff"
    v.data.Icon = {
      name = "$IconMatchBall",
      id = 2
    }
  end

  self.im.Publish(bndTeamList, TeamListData)
end

function TeamSelect:StartQuickCup(data)
  local currentTeamIndex = data.id + 1
  currentCupInfo[cupId].homeID = TeamListData[currentTeamIndex].assetId
  local buttonNo = {
    icon = "$FooterIconNo",
    label = "Cancel",
    clickEvents = {
      "evt_hide_popup"
    }
  }
  local buttonYes = {
    icon = "$FooterIconYes",
    label = "Confirm",
    clickEvents = {
      "evt_team_select",
      "evt_hide_popup"
    }
  }
  local popupData = {
    title = "INFO",
    message = "Confirm to Choose \n"..TeamListData[currentTeamIndex].teamName.."\n To Start the Cup Competition?",
    buttons = {buttonNo, buttonYes}
  }
  self.nav.Event(nil, "evt_show_popup", popupData)
end

function TeamSelect:HideSelections()
    for i = 1, 16 do
        self.im.Publish("bnd_tab" .. i .. "_visible", false)
    end
end

function TeamSelect:finalize()
  self.im.Unsubscribe(BND_TEAM_RATING)
  self.im.Unsubscribe(bndTeamList)
  self.im.Unsubscribe("bnd_cup_bg")
  self.im.UnregisterAction(ACT_TEAM_SELECT)
  self.im.UnregisterAction(ACT_CONFIRM)
  self.im.UnregisterAction(ACT_RANDOM)
  for _, tab in ipairs(self.buttonsID) do
    self.im.Unsubscribe("bnd_tab"..tab.."_visible")
  end
  self.im.UnregisterAction(ACT_selected)
  self.services.EventManagerService.UnregisterHandler(self.handlerId)
end

return TeamSelect
--- IMPROVED TEAM SELECT BY MOUNTSA ---