-- New Custom By MVNPROD --
local MenuHub = {}
local BND_MENS_VISIBLE = "bnd_mens_visible"
local BND_WOMENS_VISIBLE = "bnd_womens_visible"
local ACT_MVNPROD = "act_mvnprod"
local MENS = 1
local WOMENS = 2
function MenuHub:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {
    EventManagerService = o.api("EventManagerService")
  }
  o.handlerId = o.services.EventManagerService.RegisterHandler(function(...)
  o:handleEvent(...)
  end)
  o.buttonsID = { MENS, WOMENS }
  o.im.Subscribe(BND_MENS_VISIBLE, function()
  end)
  o.im.Subscribe(BND_WOMENS_VISIBLE, function()
  end)
  o:HideSelections()
  o.im.Publish(BND_MENS_VISIBLE, true)
  o.im.RegisterAction(ACT_MVNPROD, function(actionName, data)
    o:HideSelections()
    if o.buttonsID[data.buttonID + 1] == MENS then
      o.im.Publish(BND_MENS_VISIBLE, true)
    elseif o.buttonsID[data.buttonID + 1] == WOMENS then
      o.im.Publish(BND_WOMENS_VISIBLE, true)
    end
  end)
  return o
end
function MenuHub:HideSelections()
  self.im.Publish(BND_MENS_VISIBLE, false)
  self.im.Publish(BND_WOMENS_VISIBLE, false)
end
function MenuHub:finalize()
  self.im.Unsubscribe(BND_MENS_VISIBLE)
  self.im.Unsubscribe(BND_WOMENS_VISIBLE)
  self.im.UnregisterAction(ACT_MVNPROD)
  self.services.EventManagerService.UnregisterHandler(self.handlerId)
end
return MenuHub