-- Remod By MounTsa --

local Liga = {}
local bndMatchList = "bnd_match_list"
local bndMatchList1 = "bnd_match_list1"
local bndLogo = "bnd_logo"
local bndTeamLogo = "bnd_team_logo"
local bndTeamName = "bnd_team_name"
local ACT_ADVANCE = "act_advance"

ligaId = 1

local LeagueBackgroundIDs = {}

-- Premier League
for _, id in ipairs({13, 1925, 14, 110, 18, 19, 5, 2, 10, 144, 1, 11, 1799, 1943, 1808, 7, 9, 8, 1796, 106}) do
    LeagueBackgroundIDs[id] = 13
end

-- La Liga 
for _, id in ipairs({1860, 449, 457, 243, 461, 240, 241, 453, 448, 450, 483, 110062, 481, 479, 463, 480, 452, 110827, 1853, 468}) do
    LeagueBackgroundIDs[id] = 53
end

-- Serie A 
for _, id in ipairs({52, 46, 347, 55, 1842, 110556, 206, 110374, 39, 48, 44, 54, 45, 189, 50, 1745, 47, 110738, 111974, 111434}) do
    LeagueBackgroundIDs[id] = 31
end

-- Bundesliga 
for _, id in ipairs({175, 38, 112172, 23, 36, 32, 1831, 21, 100409, 1824, 25, 111235, 22, 110329, 10029, 169, 31, 28}) do
    LeagueBackgroundIDs[id] = 19
end

-- Ligue 1 
for _, id in ipairs({65, 69, 76, 219, 73, 66, 64, 74, 1738, 72, 71, 1530, 57, 378, 379, 1809, 217, 111817}) do
    LeagueBackgroundIDs[id] = 16
end

-- AfcU23
for _, id in ipairs({111510}) do
    LeagueBackgroundIDs[id] = 10
end

LeagueBackgroundIDs[-1] = 0

local function getLeagueBackgroundByTeam(teamID)
    local compID = LeagueBackgroundIDs[teamID] or LeagueBackgroundIDs[-1]
    return {
        name = "$LeagueBG", 
        id = compID
    }
end

local LeagueTableIDs = {}

-- Premier League
for _, id in ipairs({13, 1925, 14, 110, 18, 19, 5, 2, 10, 144, 1, 11, 1799, 1943, 1808, 7, 9, 8, 1796, 106}) do
    LeagueTableIDs[id] = 13
end

-- La Liga 
for _, id in ipairs({1860, 449, 457, 243, 461, 240, 241, 453, 448, 450, 483, 110062, 481, 479, 463, 480, 452, 110827, 1853, 468}) do
    LeagueTableIDs[id] = 53
end

-- Serie A 
for _, id in ipairs({52, 46, 347, 55, 1842, 110556, 206, 110374, 39, 48, 44, 54, 45, 189, 50, 1745, 47, 110738, 111974, 111434}) do
    LeagueTableIDs[id] = 31
end

-- Bundesliga 
for _, id in ipairs({175, 38, 112172, 23, 36, 32, 1831, 21, 100409, 1824, 25, 111235, 22, 110329, 10029, 169, 31, 28}) do
    LeagueTableIDs[id] = 19
end

-- Ligue 1 
for _, id in ipairs({65, 69, 76, 219, 73, 66, 64, 74, 1738, 72, 71, 1530, 57, 378, 379, 1809, 217, 111817}) do
    LeagueTableIDs[id] = 16
end

-- AfcU23
for _, id in ipairs({111510}) do
    LeagueTableIDs[id] = 10
end

LeagueTableIDs[-1] = 0

local function getLeagueTableByTeam(teamID)
    local compID = LeagueTableIDs[teamID] or LeagueTableIDs[-1]
    return {
        name = "$TableAllCareer", 
        id = compID
    }
end

if not round then
  round = 1
else 
  round = round
end

if not selectedteam then
  selectedteam = 0
else 
  selectedteam = selectedteam
end

currentMatch = {
  HomeTeamID = 0,
  AwayTeamID = 0,
  HomeKitIndex = 0,
  AwayKitIndex = 1
}

local rivalListData = {}
local matchesPlayed = 0

function Liga:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {
    settingsService = o.api("SettingsService"),
    SquadManagementService = o.api("SquadMgtService")
  }

  o.currentOptions = o.services.settingsService.GetCurrentOptions()
  o.Init()
  
  o.im.Subscribe(bndMatchList, function()
     o:publishMatchRows()
  end)
  
  o.im.Subscribe(bndMatchList1, function()
     o:publishMatchRows2()
  end)
 
  o.im.Subscribe("bnd_leaguebackground", function()
    local leagueBg = getLeagueBackgroundByTeam(currentSelectedTeamID)
    o.im.Publish("bnd_leaguebackground", leagueBg)
end)
  
  o.im.Subscribe("bnd_leaguetable", function()
    local leagueBg = getLeagueTableByTeam(currentSelectedTeamID)
    o.im.Publish("bnd_leaguetable", leagueBg)
end)

  o.im.Subscribe(bndLogo, function()  
    o.im.Publish(bndLogo, {name = "$LogoStandings", id = currentSelectedTeamID})   
  end)

  o.im.Subscribe(bndTeamLogo, function()  
    o.im.Publish(bndTeamLogo, {name = "$Crest64x64", id = currentSelectedTeamID})   
  end)
  
  o.im.Subscribe(bndTeamName, function()  
    o.im.Publish(bndTeamName, o.loc.LocalizeString("TeamName_Abbr15_"..currentSelectedTeamID))       
  end)
  
  o.im.Subscribe("bnd_match_label", function()
    o:publishMatchLabel()
  end)
  
  o.im.Subscribe("bnd_point_label", function()
    o:publishMatchLabel()
  end)
  
  o.im.Subscribe("bnd_finish_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("bnd_team_label", function()
    o:publishLabel()
  end)
  
  o.im.Subscribe("bnd_matchup_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("bnd_matchday_label", function()
    o:publishLabel()
  end)
  
  o.im.Subscribe("bnd_league_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("bnd_advance_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("bnd_month_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.RegisterAction(ACT_ADVANCE, function(actionName, data)
    if data then
      o:PlayMatch(data)
    end
  end)

  o.im.RegisterAction("act_nextteam", function() o:NextTeam() end)
  o.im.RegisterAction("act_previousteam", function() o:PrevTeam() end)
  o.im.RegisterAction("act_next", function() o:NextMatchday() end)
  o.im.RegisterAction("act_decrease", function() o:PrevMatchday() end)
  
  return o
end

function Liga:Init()
  local LigaGroupingList = LigaGrouping[ligaId]
  for i = 1, table.getn(LigaGroupingList) do
    local obj = {
      homeID = LigaGroupingList[i][1],
      awayID = LigaGroupingList[i][2],
      homeScore = LigaGroupingList[i][4],
      awayScore = LigaGroupingList[i][5],
      data = {}
    }
    table.insert(rivalListData, obj)
  end
end

function Liga:publishLabel()
  self.im.Publish("bnd_matchday_label", "Matchday " .. round)
  if selectedteam == 0 then
    self.im.Publish("bnd_team_label", "Matchday ")
  else
    self.im.Publish("bnd_team_label", self.loc.LocalizeString("TeamName_Abbr15_" .. TeamList[selectedteam]))
  end
end

local SelectedTeamID = (selectedteam ~= 0) and TeamList[selectedteam] or nil

function Liga:publishMatchRows2()
  local teamDataList = {}
  local SelectedTeamID = nil

  if currentSelectedTeamID and currentSelectedTeamID ~= 0 then
    SelectedTeamID = currentSelectedTeamID
  elseif selectedteam and selectedteam ~= 0 then
    SelectedTeamID = TeamList[selectedteam]
  elseif currentMatch and currentMatch.HomeTeamID and currentMatch.HomeTeamID ~= 0 then
    SelectedTeamID = currentMatch.HomeTeamID
  end

  for _, teamID in ipairs(TeamList) do
    local teamData = {}
    teamData.TeamCrest = { name = "$Crest64x64", id = teamID }
    teamData.TeamName = self.loc.LocalizeString("TeamName_Abbr15_" .. teamID)
    teamData.TeamWin = tostring(GetTeamWins(teamID))
    teamData.TeamDraw = tostring(GetTeamDraws(teamID))
    teamData.TeamPoint = tonumber(GetTeamPoints(teamID))
    teamData.TeamLoss = tostring(GetTeamLosses(teamID))
    teamData.TeamGA = tonumber(GetTeamGoalsScored(teamID))
    teamData.TeamGC = tonumber(GetTeamGoalsConceded(teamID))
    teamData.TeamGD = teamData.TeamGA - teamData.TeamGC
    teamData.Teammp = GLOBAL_MATCHUP_COUNT
    teamData.clickAction = "ViewTeamDetails_" .. teamID
    teamData.TeamScoreFontColor = "0xffffff"
    teamData.TeamNameFontColor = "0xffffff"
    teamData.FontColor = "0xffffff"

    if SelectedTeamID and teamID == SelectedTeamID then
      teamData.Icon = { name = "$checkmark", id = teamID }
    else
      teamData.Icon = nil
    end

    teamData.RightText = ""
    table.insert(teamDataList, {data = teamData})
  end

  table.sort(teamDataList, function(a, b)
    if a.data.TeamPoint ~= b.data.TeamPoint then
      return a.data.TeamPoint > b.data.TeamPoint
    end
    if a.data.TeamGD ~= b.data.TeamGD then
      return a.data.TeamGD > b.data.TeamGD
    end
    return a.data.TeamName < b.data.TeamName
  end)

  local allZeroPoints = true
  for _, team in ipairs(teamDataList) do
    if team.data.TeamPoint > 0 then
      allZeroPoints = false
      break
    end
  end

  if allZeroPoints then
    table.sort(teamDataList, function(a, b)
      return a.data.TeamName < b.data.TeamName
    end)
  end

  for i, team in ipairs(teamDataList) do
    team.data.Teampos = tostring(i) .. ""
  end

  self.im.Publish(bndMatchList1, teamDataList)
end

function Liga:publishMatchRows()
  local filteredRivalListData = {}
  local matchCount = (#TeamList / 2)

  local SelectedTeamID = nil
  if currentSelectedTeamID and currentSelectedTeamID ~= 0 then
    SelectedTeamID = currentSelectedTeamID
  elseif selectedteam and selectedteam ~= 0 then
    SelectedTeamID = TeamList[selectedteam]
  end

  for i, v in ipairs(rivalListData) do
    local shouldIncludeMatch = false

    if selectedteam == 0 then
      shouldIncludeMatch = i >= ((round * matchCount) - (matchCount - 1)) and i <= (round * matchCount)
    else
      shouldIncludeMatch = (rivalListData[i].homeID == TeamList[selectedteam] or rivalListData[i].awayID == TeamList[selectedteam])
    end

    if shouldIncludeMatch then
      v.data.TeamHomeCrest = { name = "$Crest64x64", id = rivalListData[i].homeID }
      v.data.TeamAwayCrest = { name = "$Crest64x64", id = rivalListData[i].awayID }
      v.data.TeamHomeName = self.loc.LocalizeString("TeamName_Abbr3_" .. rivalListData[i].homeID)
      v.data.TeamAwayName = self.loc.LocalizeString("TeamName_Abbr3_" .. rivalListData[i].awayID)

      local maxRowsWithScores = GLOBAL_MATCHUP_COUNT * 10
      if i <= maxRowsWithScores then
        rivalListData[i].data.MatchScore = rivalListData[i].homeScore .. " - " .. rivalListData[i].awayScore
      else
        rivalListData[i].data.MatchScore = "  vs"
      end

      v.data.TeamScoreFontColor = "0xffffff"
      v.data.TeamNameFontColor = "0x4A2C6D"
      v.data.FontColor = "0x4A2C6D"

      v.data.HomeIcon = (rivalListData[i].homeID == SelectedTeamID) and { name = "$checkmark", id = rivalListData[i].homeID } or nil
      v.data.AwayIcon = (rivalListData[i].awayID == SelectedTeamID) and { name = "$checkmark", id = rivalListData[i].awayID } or nil
      
      v.data.RightText = ""
      table.insert(filteredRivalListData, v)
    end
  end
  
  self.im.Publish(bndMatchList, filteredRivalListData)
end

function Liga:NextMatchday()
  if not TeamList or #rivalListData == 0 then return end
  local matchCount = #TeamList / 2
  local maxRound = #rivalListData / matchCount
  if round < maxRound then
    round = round + 1
    self:publishMatchRows2()
    self:publishMatchRows()
    self:publishLabel()
  end
end

function Liga:PrevMatchday()
  if round > 1 then
    round = round - 1
    self:publishMatchRows2()
    self:publishMatchRows()
    self:publishLabel()
  end
end

function Liga:NextTeam()
  if not TeamList then return end
  local teamCount = #TeamList
  selectedteam = selectedteam + 1
  if selectedteam > teamCount then
    selectedteam = 0
  end
  self:publishMatchRows2()
  self:publishMatchRows()
  self:publishLabel()
end

function Liga:PrevTeam()
  if not TeamList then return end
  local teamCount = #TeamList
  if selectedteam > 0 then
    selectedteam = selectedteam - 1
  else
    selectedteam = teamCount
  end
  self:publishMatchRows2()
  self:publishMatchRows()
  self:publishLabel()
end

function Liga:finalize()
  self.im.UnregisterAction(ACT_ADVANCE)
  self.im.Unsubscribe("bnd_match_list")
  self.im.Unsubscribe("bnd_match_list1")
  self.im.Unsubscribe("bnd_matchday_label")
  self.im.Unsubscribe("bnd_point_label")
  self.im.Unsubscribe("bnd_team_label")
  self.im.Unsubscribe("bnd_matchup_label")
  self.im.Unsubscribe("bnd_matchdate_label")
  self.im.Unsubscribe("bnd_league_label")
  self.im.Unsubscribe("bnd_advance_label")
  self.im.Unsubscribe("bnd_month_label")
  self.im.Unsubscribe("bnd_finish_label")
  rivalListData = {}
end

return Liga