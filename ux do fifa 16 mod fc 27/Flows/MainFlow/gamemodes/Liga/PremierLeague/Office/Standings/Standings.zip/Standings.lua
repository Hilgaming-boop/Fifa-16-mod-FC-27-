-- Mod By MVN PROD --
-- League Mode Division --

local Liga = {}
local bndMatchList = "bnd_match_list"
local bndMatchList1 = "bnd_match_list1"
local bndBackgroundCareer = "bnd_background_career"
local bndTableCareer = "bnd_table_career"
local bndStandingsCareer = "bnd_standings_career"
local bndLogo = "bnd_logo"
local bndTeamLogo = "bnd_team_logo"
local bndTeamName = "bnd_team_name"
local ACT_ADVANCE = "act_advance"

ligaId = 1
if not round then
  round = 1
else 
  round = round
end

if not selectedteam then
  selectedteam = 0
else 
  selectedteam = selectedteam
end

currentMatch = {
  HomeTeamID = 0,
  AwayTeamID = 0,
  HomeKitIndex = 0,
  AwayKitIndex = 1
}

-- Dev2
local rivalListData = {}
local matchesPlayed = 0  -- Counter to track the number of matches played

function Liga:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {
    settingsService = o.api("SettingsService"),
    SquadManagementService = o.api("SquadMgtService")
  }

  o.currentOptions = o.services.settingsService.GetCurrentOptions()
  o.Init()
  
  o.im.Subscribe(bndMatchList, function()
     o:publishMatchRows()
  end)
  
  o.im.Subscribe(bndMatchList1, function()
     o:publishMatchRows2()
  end)
 
  o.im.Subscribe(bndBackgroundCareer, function()  
    o.im.Publish(bndBackgroundCareer, {name = "$BackgroundCareer", id = currentSelectedTeamID})   
  end)
  
  o.im.Subscribe(bndTableCareer, function()  
    o.im.Publish(bndTableCareer, {name = "$TableCareer", id = currentSelectedTeamID})   
  end)
  
  o.im.Subscribe(bndStandingsCareer, function()  
    o.im.Publish(bndStandingsCareer, {name = "$Logo_Standing", id = currentSelectedTeamID})   
  end)

  o.im.Subscribe(bndLogo, function()  
    o.im.Publish(bndLogo, {name = "$LogoStandings", id = currentSelectedTeamID})   
  end)

  o.im.Subscribe(bndTeamLogo, function()  
    o.im.Publish(bndTeamLogo, {name = "$Crest64x64", id = currentSelectedTeamID})   
  end)
  
  o.im.Subscribe(bndTeamName, function()  
        o.im.Publish(bndTeamName, o.loc.LocalizeString("TeamName_Abbr15_"..currentSelectedTeamID))       
    end)
  
  o.im.Subscribe("bnd_match_label", function()
    o:publishMatchLabel()
  end)
  
  o.im.Subscribe("bnd_point_label", function()

    o:publishMatchLabel()

  end)
  
  o.im.Subscribe("bnd_finish_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("bnd_team_label", function()
    o:publishLabel()
  end)
  
  o.im.Subscribe("bnd_matchup_label", function()

    o:publishFinishLabel()

  end)
  
  o.im.Subscribe("bnd_matchday_label", function()

    o:publishLabel()

  end)
  
  o.im.Subscribe("bnd_league_label", function()

    o:publishFinishLabel()

  end)
  
  o.im.Subscribe("bnd_advance_label", function()

    o:publishFinishLabel()

  end)
  
  o.im.Subscribe("bnd_month_label", function()

    o:publishFinishLabel()

  end)
  
  o.im.RegisterAction(ACT_ADVANCE, function(actionName, data)
    if data then
      o:PlayMatch(data)
    end
  end)

  o.im.RegisterAction("act_nextteam", function() o:NextTeam() end)
  o.im.RegisterAction("act_previousteam", function() o:PrevTeam() end)
  o.im.RegisterAction("act_next", function() o:NextMatchday() end)
  o.im.RegisterAction("act_decrease", function() o:PrevMatchday() end)
  
  return o
end

------------------------------------------------------------------------------------------

function Liga:Init()
  local LigaGroupingList = LigaGrouping[ligaId]
  for i = 1, table.getn(LigaGroupingList) do
    local obj = {
      homeID = LigaGroupingList[i][1],
      awayID = LigaGroupingList[i][2],
      homeScore = LigaGroupingList[i][4],
      awayScore = LigaGroupingList[i][5],
 
      data = {}
    }
    table.insert(rivalListData, obj)
  end
end

------------------------------------------------------------------------------------------
function Liga:publishLabel()
  self.im.Publish("bnd_matchday_label", "Matchday " .. round)
  if selectedteam == 0 then
    self.im.Publish("bnd_team_label", "Matchday ")
  else
    self.im.Publish("bnd_team_label", self.loc.LocalizeString("TeamName_Abbr15_" .. TeamList[selectedteam]))
  end
end

------------------------------------------------------------------------------------------

function Liga:publishMatchRows2()
  local teamDataList = {}

  -- Loop through all teams in TeamList
  for _, teamID in ipairs(TeamList) do
    local teamData = {}
    teamData.TeamCrest = {
      name = "$Crest64x64",
      id = teamID
    }
    teamData.TeamName = self.loc.LocalizeString("TeamName_Abbr15_" .. teamID)
    teamData.TeamWin = tostring(GetTeamWins(teamID))
    teamData.TeamDraw = tostring(GetTeamDraws(teamID))
    teamData.TeamPoint = tonumber(GetTeamPoints(teamID)) -- Convert to number for sorting
    teamData.TeamLoss = tostring(GetTeamLosses(teamID))
    teamData.TeamGA = tonumber(GetTeamGoalsScored(teamID)) -- Convert for calculations
    teamData.TeamGC = tonumber(GetTeamGoalsConceded(teamID)) -- Convert for calculations
    teamData.TeamGD = teamData.TeamGA - teamData.TeamGC -- Calculate Goal Difference
    teamData.Teammp = GLOBAL_MATCHUP_COUNT
    teamData.clickAction = "ViewTeamDetails_" .. teamID

    -- Set default font and icon properties
    teamData.TeamScoreFontColor = "0xffffff"
    teamData.TeamNameFontColor = "0xffffff"
    teamData.FontColor = "0xffffff"
    teamData.Icon = {
      name = "$IconTeam",
      id = teamID
    }
    teamData.RightText = ""

    -- Add team data to the list
    table.insert(teamDataList, {data = teamData})
  end

  -- Sort the team list
  table.sort(teamDataList, function(a, b)
    -- Primary sort: Points (descending)
    if a.data.TeamPoint ~= b.data.TeamPoint then
      return a.data.TeamPoint > b.data.TeamPoint
    end

    -- Secondary sort: Goal Difference (descending)
    if a.data.TeamGD ~= b.data.TeamGD then
      return a.data.TeamGD > b.data.TeamGD
    end

    -- Tertiary sort: Alphabetical order by TeamName (ascending)
    return a.data.TeamName < b.data.TeamName
  end)

  -- Special case: If all points are 0, sort alphabetically
  local allZeroPoints = true
  for _, team in ipairs(teamDataList) do
    if team.data.TeamPoint > 0 then
      allZeroPoints = false
      break
    end
  end

  if allZeroPoints then
    table.sort(teamDataList, function(a, b)
      return a.data.TeamName < b.data.TeamName
    end)
  end

  -- Assign Teampos based on sorted order
  for i, team in ipairs(teamDataList) do
    team.data.Teampos = tostring(i) .. ""
  end

  -- Publish the sorted team list
  self.im.Publish(bndMatchList1, teamDataList)
end

------------------------------------------------------------------------------------------

function Liga:publishMatchRows()
  local filteredRivalListData = {}
  local matchCount = (#TeamList / 2)

  -- Loop through all matches in rivalListData
  for i, v in ipairs(rivalListData) do
    local shouldIncludeMatch = false

    if selectedteam == 0 then
      shouldIncludeMatch = i >= ((round * matchCount) - (matchCount - 1)) and i <= (round * matchCount)
    else
      shouldIncludeMatch = (rivalListData[i].homeID == TeamList[selectedteam] or rivalListData[i].awayID == TeamList[selectedteam])
    end

    if shouldIncludeMatch then
      -- Populate match data
      v.data.TeamHomeCrest = {
        name = "$Crest64x64",
        id = rivalListData[i].homeID
      }
      v.data.TeamAwayCrest = {
        name = "$Crest64x64",
        id = rivalListData[i].awayID
      }
      v.data.TeamHomeName = self.loc.LocalizeString("TeamName_Abbr3_" .. rivalListData[i].homeID)
      v.data.TeamAwayName = self.loc.LocalizeString("TeamName_Abbr3_" .. rivalListData[i].awayID)

      -- Determine how many rows should show scores based on GLOBAL_MATCHUP_COUNT
      local maxRowsWithScores = GLOBAL_MATCHUP_COUNT * 10

      if i <= maxRowsWithScores then
        rivalListData[i].data.MatchScore = rivalListData[i].homeScore .. "  -  " .. rivalListData[i].awayScore
      else
        rivalListData[i].data.MatchScore = "   vs"
      end

      v.data.TeamScoreFontColor = "0xffffff"
      v.data.TeamNameFontColor = "0x4A2C6D"
      v.data.FontColor = "0x4A2C6D"

      -- Set icon and right text based on match status
      if not rivalListData[i].isUnlock then
        v.data.Icon = { name = "$", id = 1 }
        v.data.RightText = ""
      else
        v.data.Icon = { name = "$", id = 2 }
        v.data.RightText = ""
      end

      -- Add the match to the filtered list
      table.insert(filteredRivalListData, v)
    end
  end
  
  -- Publish only the filtered matches
  self.im.Publish(bndMatchList, filteredRivalListData)
end

function Liga:NextMatchday()
  if not TeamList or #rivalListData == 0 then return end
  local matchCount = #TeamList / 2
  local maxRound = #rivalListData / matchCount
  if round < maxRound then
    round = round + 1
    self:publishMatchRows2()
    self:publishMatchRows()
	  self:publishLabel()
  end
end

function Liga:PrevMatchday()
  if round > 1 then
    round = round - 1
    self:publishMatchRows2()
    self:publishMatchRows()
	  self:publishLabel()
  end
end

function Liga:NextTeam()
  if not TeamList then return end
  local teamCount = #TeamList
  selectedteam = selectedteam + 1
  if selectedteam > teamCount then
    selectedteam = 0
  end
  self:publishMatchRows2()
  self:publishMatchRows()
    self:publishLabel()
end

function Liga:PrevTeam()
  if not TeamList then return end
  local teamCount = #TeamList
  if selectedteam > 0 then
    selectedteam = selectedteam - 1
  else
    selectedteam = teamCount
  end
  self:publishMatchRows2()
  self:publishMatchRows()
  self:publishLabel()
end

function Liga:finalize()
  self.im.UnregisterAction(ACT_ADVANCE)
  self.im.Unsubscribe("bnd_match_list")
  self.im.Unsubscribe("bnd_match_list1")
  self.im.Unsubscribe("bnd_matchday_label")
  self.im.Unsubscribe("bnd_point_label")
  self.im.Unsubscribe("bnd_team_label")
  self.im.Unsubscribe("bnd_matchup_label")
  self.im.Unsubscribe("bnd_matchdate_label")
  self.im.Unsubscribe("bnd_league_label")
  self.im.Unsubscribe("bnd_advance_label")
  self.im.Unsubscribe("bnd_month_label")
  self.im.Unsubscribe("bnd_finish_label")
  rivalListData = {}
end

return Liga

-- Thanks : Ma'ruf Id & Laosiji --
-- @mvnprod.official - Remain Be Creative --