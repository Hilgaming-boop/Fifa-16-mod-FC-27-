
-- New Custom EventInfo By MVNPROD --

local EventInfo = {}
local OverlaysIdContainer, OverlayParam, eventmanager = ...
local Overlays = OverlaysIdContainer.Overlays.OVERLAY_TYPE
local EventTypes = eventmanager.FE.FIFA.EventTypes

local BND_VISIBLE = "bnd_visible"
local BND_NATIONALIZATION = "bnd_nationalization"
local BND_DATA = "bnd_data"
local BND_ALPHA = "bnd_alpha"
local beforeHomeScore = 0
local beforeAwayScore = 0
local nowHomeScore = 0
local nowAwayScore = 0

local goalStatistics = {}
--local isinitialized = 0
local initialized = false

local leagueIDs = {
   Algeria = 2262,
   Afc = 365,
   Argentina = 353,
   AsianCupU23 = 2264,
   Belgium = 4,
   Brazil = 7,
   Classic = 1245,
   Classic2 = 1246,
   ChampionshipEfl = 14,
   Denmark = 1,
   D1Arkema = 2218,
   Ecuador = 2018,
   Egypt = 2231,
   England = 13,
   France = 16,
   France2 = 17,
   Germany = 19,
   Germany2 = 20,
   Indonesia = 2235,
   International = 78,
   International2 = 2136,
   Italy = 31,
   Japan = 349,
   KoreaRepublic = 83,
   LeagueOneEfl = 60,
   LigaF = 2222,
   Malaysia = 2237,
   Mexico = 341,
   Morocco = 2250,
   Netherlands = 10,
   PegadaianLiga2 = 2254,
   Portugal = 308,
   RestOfWorld = 76,
   RestOfWorld2 = 77,
   Rusia = 67,
   SaudiArabia = 350,
   Scotland = 50,
   SouthAfrica = 347,
   Spain = 53,
   Spain2 = 54,
   Switzerland = 189,
   Thailand = 2252,
   Turkey = 68,
   Uefa = 2236,
   UefaUel = 2238,
   UefaWomens = 2240,
   Ukraine = 332,
   UnitedStates = 39,
   USANWSL = 2221,
   VanaramaFootballLeague = 62,
   Vietnam = 2260,
   WomensSuperLeague = 2216
}
AlgeriaInfo = {   
  bnd_fontFace = "$DINPro-CondBold", 
  bnd_forceCaps = true,
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_bg1_color = "0xffffff",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 360,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 10,
  
  bnd_bg2_color = "0x1AFE68",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 360,
  bnd_bg2_color_height = 25,
  bnd_bg2_color_left = 10,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = -14,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 14,
  bnd_goal_player_name_left = 20,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 14,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 230,
  -- Count
  bnd_goal_player_count_fontColor = "0xF5F5F5",
  bnd_goal_player_count_fontSize = 0,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 15,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x461648",
  bnd_goal_player_desc_fontSize = 0,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x461648",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = -3,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0,
  -- Logo
  bnd_logo = {
    name = "$LeagueLogo",
    id = 2262
  },  
  bnd_logo_color = "0x1AFE68",
  bnd_logo_color_top = 0,
  bnd_logo_color_bottom = 0,
  bnd_logo_alignV = "CENTER",
  bnd_logo_alignH = "LEFT",
  bnd_logo_width = 70,
  bnd_logo_height = 70,
  bnd_logo_top = 0,
  bnd_logo_bottom = 0,
  bnd_logo_left = -70,
  bnd_logo_right = 0
}
AsianCupU23Info = {   
  bnd_forceCaps = true,
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_bg1_color = "0xffffff",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 360,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 10,
  
  bnd_bg2_color = "0x2B4271",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 360,
  bnd_bg2_color_height = 25,
  bnd_bg2_color_left = 10,
  -- Avatar
  bnd_bg_avatar_color = "0xFCDD10",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = -14,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 14,
  bnd_goal_player_name_left = 20,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 14,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 230,
  -- Count
  bnd_goal_player_count_fontColor = "0xF5F5F5",
  bnd_goal_player_count_fontSize = 0,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 15,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x461648",
  bnd_goal_player_desc_fontSize = 0,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0xffffff",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = -3,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0,
  -- Logo
  bnd_logo = {
    name = "$LeagueLogo",
    id = 2264
  },  
  bnd_logo_color = "0xffffff", 
  bnd_logo_color_top = 0,
  bnd_logo_color_bottom = 0,
  bnd_logo_alignV = "CENTER",
  bnd_logo_alignH = "LEFT",
  bnd_logo_width = 70,
  bnd_logo_height = 70,
  bnd_logo_top = 0,
  bnd_logo_bottom = 0,
  bnd_logo_left = -70,
  bnd_logo_right = 0
}
BrazilInfo = {   
  bnd_forceCaps = true,
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_bg1_color = "0xffffff",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 360,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 10,
  
  bnd_bg2_color = "0x1AFE68",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 360,
  bnd_bg2_color_height = 25,
  bnd_bg2_color_left = 10,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = -14,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 14,
  bnd_goal_player_name_left = 20,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 14,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 230,
  -- Count
  bnd_goal_player_count_fontColor = "0xF5F5F5",
  bnd_goal_player_count_fontSize = 0,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 15,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x461648",
  bnd_goal_player_desc_fontSize = 0,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x461648",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = -3,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0,
  -- Logo
  bnd_logo = {
    name = "$LeagueLogo",
    id = "7_1"
  },  
  bnd_logo_color = "0x1AFE68",
  bnd_logo_color_top = 0,
  bnd_logo_color_bottom = 0,
  bnd_logo_alignV = "CENTER",
  bnd_logo_alignH = "LEFT",
  bnd_logo_width = 70,
  bnd_logo_height = 70,
  bnd_logo_top = 0,
  bnd_logo_bottom = 0,
  bnd_logo_left = -70,
  bnd_logo_right = 0
}
ClassicInfo = {
  bnd_forceCaps = true,
  bnd_fontFace = "$DINPro-CondBold", 
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 475,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_bg1_color = "0x6C0016",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xFFB700",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 30,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x000000",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 40,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x474BE5",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x6C0016",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 21,
  bnd_goal_player_name_bottom = 0,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0x6C0016",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 19,
  -- Count
  bnd_goal_player_count_fontColor = "0xffffff",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 15,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 80,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xffffff",
  bnd_goal_player_desc_fontSize = 18,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 15,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 10,
  -- Type
  bnd_goal_type_fontColor = "0xffffff",
  bnd_goal_type_fontSize = 18,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "LEFT",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 15,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0
}
ChampionshipEflInfo = {   
  bnd_forceCaps = true,
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_bg1_color = "0xffffff",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 360,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 10,
  
  bnd_bg2_color = "0x1AFE68",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 360,
  bnd_bg2_color_height = 25,
  bnd_bg2_color_left = 10,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = -14,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 14,
  bnd_goal_player_name_left = 20,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 14,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 230,
  -- Count
  bnd_goal_player_count_fontColor = "0xF5F5F5",
  bnd_goal_player_count_fontSize = 0,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 15,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x461648",
  bnd_goal_player_desc_fontSize = 0,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x461648",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = -3,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0,
  -- Logo
  bnd_logo = {
    name = "$LeagueLogo",
    id = 14
  },  
  bnd_logo_color = "0x1AFE68",
  bnd_logo_color_top = 0,
  bnd_logo_color_bottom = 0,
  bnd_logo_alignV = "CENTER",
  bnd_logo_alignH = "LEFT",
  bnd_logo_width = 70,
  bnd_logo_height = 70,
  bnd_logo_top = 0,
  bnd_logo_bottom = 0,
  bnd_logo_left = -70,
  bnd_logo_right = 0
}
DenmarkInfo = {   
  bnd_forceCaps = true,
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_bg1_color = "0xffffff",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 360,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 10,
  
  bnd_bg2_color = "0x1AFE68",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 360,
  bnd_bg2_color_height = 25,
  bnd_bg2_color_left = 10,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = -14,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 14,
  bnd_goal_player_name_left = 20,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 14,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 230,
  -- Count
  bnd_goal_player_count_fontColor = "0xF5F5F5",
  bnd_goal_player_count_fontSize = 0,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 15,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x461648",
  bnd_goal_player_desc_fontSize = 0,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x461648",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = -3,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0,
  -- Logo
  bnd_logo = {
    name = "$LeagueLogo",
    id = 1
  },  
  bnd_logo_color = "0x1AFE68",
  bnd_logo_color_top = 0,
  bnd_logo_color_bottom = 0,
  bnd_logo_alignV = "CENTER",
  bnd_logo_alignH = "LEFT",
  bnd_logo_width = 70,
  bnd_logo_height = 70,
  bnd_logo_top = 0,
  bnd_logo_bottom = 0,
  bnd_logo_left = -70,
  bnd_logo_right = 0
}
D1ArkemaInfo = {
  bnd_forceCaps = true,
  bnd_fontFace = "$DINPro-CondBold", 
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x143673",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xF5F5F5",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 30,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x061A3E",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 30,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x061A3E",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xF5F5F5",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xF5F5F5",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
EAFCInfo = {   
  bnd_forceCaps = true,
  bnd_fontFace = "$Epl", 
  bnd_forceCaps = true,
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_background = {
    name = "$BackroundGoal",  
    id = 0     
 },
  bnd_background_alignV = "CENTER",
  bnd_background_alignH = "LEFT",
  bnd_background_width = 250,
  bnd_background_height = 250,  
  bnd_background_top = -50,
  bnd_background_left = 20,   
  -- Avatar
  bnd_bg_avatar_color_alpha = 0,
  bnd_bg_avatar_color = "0x00E675",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_width = 100,
  bnd_goal_player_avatar_height = 100,
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 50,
  bnd_goal_player_avatar_left = 80,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 30,
  bnd_team_crest_height = 30,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = -136,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 4,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontFace = "$CruyffSansLight",
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 10,
  bnd_goal_player_name_alignV = "BOTTOM",
  bnd_goal_player_name_alignH = "LEFT",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 80,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 14,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "CENTER",
  bnd_goal_player_level_top = -100,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 100,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 14,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "CENTER",
  bnd_goal_player_count_top = -20,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = -10,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 14,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 70,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = -30,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 14,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = -35,
  -- Time
  bnd_goal_time_fontFace = "$Epl",
  bnd_goal_time_fontColor = "0x000000",
  bnd_goal_time_fontSize = 14,
  bnd_goal_time_alignV = "CENTER",
  bnd_goal_time_alignH = "CENTER",
  bnd_goal_time_top = -90,
  bnd_goal_time_bottom = 0,
  bnd_goal_time_left = 0,
  bnd_goal_time_right = -10
}
EcuadorInfo = {   
  bnd_forceCaps = true,
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_bg1_color = "0xffffff",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 360,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 10,
  
  bnd_bg2_color = "0x1AFE68",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 360,
  bnd_bg2_color_height = 25,
  bnd_bg2_color_left = 10,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = -14,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 14,
  bnd_goal_player_name_left = 20,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 14,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 230,
  -- Count
  bnd_goal_player_count_fontColor = "0xF5F5F5",
  bnd_goal_player_count_fontSize = 0,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 15,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x461648",
  bnd_goal_player_desc_fontSize = 0,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x461648",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = -3,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0,
  -- Logo
  bnd_logo = {
    name = "$LeagueLogo",
    id = 2018
  },  
  bnd_logo_color = "0x1AFE68",
  bnd_logo_color_top = 0,
  bnd_logo_color_bottom = 0,
  bnd_logo_alignV = "CENTER",
  bnd_logo_alignH = "LEFT",
  bnd_logo_width = 70,
  bnd_logo_height = 70,
  bnd_logo_top = 0,
  bnd_logo_bottom = 0,
  bnd_logo_left = -70,
  bnd_logo_right = 0
}
EgyptInfo = {   
  bnd_forceCaps = true,
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_bg1_color = "0xffffff",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 360,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 10,
  
  bnd_bg2_color = "0x1AFE68",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 360,
  bnd_bg2_color_height = 25,
  bnd_bg2_color_left = 10,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = -14,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 14,
  bnd_goal_player_name_left = 20,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 14,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 230,
  -- Count
  bnd_goal_player_count_fontColor = "0xF5F5F5",
  bnd_goal_player_count_fontSize = 0,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 15,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x461648",
  bnd_goal_player_desc_fontSize = 0,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x461648",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = -3,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0,
  -- Logo
  bnd_logo = {
    name = "$LeagueLogo",
    id = 2231
  },  
  bnd_logo_color = "0x1AFE68",
  bnd_logo_color_top = 0,
  bnd_logo_color_bottom = 0,
  bnd_logo_alignV = "CENTER",
  bnd_logo_alignH = "LEFT",
  bnd_logo_width = 70,
  bnd_logo_height = 70,
  bnd_logo_top = 0,
  bnd_logo_bottom = 0,
  bnd_logo_left = -70,
  bnd_logo_right = 0
}
EnglandInfo = {
  bnd_fontFace = "$Epl",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_background = {
    name = "$BackroundGoal",  
    id = 0     
 },
  bnd_background_alignV = "CENTER",
  bnd_background_alignH = "LEFT",
  bnd_background_width = 320,
  bnd_background_height = 320,  
  bnd_background_top = 10,
  bnd_background_left = 20,   
  -- Avatar
  bnd_bg_avatar_color_alpha = 0,
  bnd_bg_avatar_color = "0x00E675",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_width = 90,
  bnd_goal_player_avatar_height = 90,
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 50,
  bnd_goal_player_avatar_left = 260,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 85,
  bnd_team_crest_height = 85,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 10,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 4,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xc82727",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 100,
  bnd_goal_team_name_left = 160,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 20,
  bnd_goal_player_name_alignV = "BOTTOM",
  bnd_goal_player_name_alignH = "LEFT",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 85,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x1E2930",
  bnd_goal_player_level_fontSize = 0,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "CENTER",
  bnd_goal_player_level_top = -100,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 100,
  -- Count
  bnd_goal_player_count_fontColor = "0x1E2930",
  bnd_goal_player_count_fontSize = 14,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "CENTER",
  bnd_goal_player_count_top = -35,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = -60,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x1E2930",
  bnd_goal_player_desc_fontSize = 13,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = -55,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 25,
  -- Type
  bnd_goal_type_fontColor = "0x1E2930",
  bnd_goal_type_fontSize = 12,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = -35,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 25,
  -- Time
  bnd_goal_time_fontFace = "$Epl",
  bnd_goal_time_fontColor = "0x1E2930",
  bnd_goal_time_fontSize = 14,
  bnd_goal_time_alignV = "CENTER",
  bnd_goal_time_alignH = "CENTER",
  bnd_goal_time_top = -55,
  bnd_goal_time_bottom = 0,
  bnd_goal_time_left = 0,
  bnd_goal_time_right = -60
}
FranceInfo = {
  bnd_fontFace = "$Ligue1",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_background = {
    name = "$BackroundGoal",  
    id = 3  
 },
  bnd_background_alignV = "CENTER",
  bnd_background_alignH = "LEFT",
  bnd_background_width = 320,
  bnd_background_height = 320,  
  bnd_background_top = 10,
  bnd_background_left = 20,   
  -- Avatar
  bnd_bg_avatar_color_alpha = 0,
  bnd_bg_avatar_color = "0x00E675",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_width = 70,
  bnd_goal_player_avatar_height = 70,
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 60,
  bnd_goal_player_avatar_left = 55,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 50,
  bnd_team_crest_height = 50,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 7,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 20,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 88,
  bnd_goal_team_name_left = 163,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 20,
  bnd_goal_player_name_alignV = "BOTTOM",
  bnd_goal_player_name_alignH = "LEFT",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 80,
  bnd_goal_player_name_left = 150,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontFace = "$CruyffSansExpanded",
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 30,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "CENTER",
  bnd_goal_player_level_top = -50,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 130,
  -- Count
  bnd_goal_player_count_fontColor = "0xffffff",
  bnd_goal_player_count_fontSize = 14,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "CENTER",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = -20,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = -150,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xffffff",
  bnd_goal_player_desc_fontSize = 16,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = -7,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 30,
  -- Type
  bnd_goal_type_fontFace = "$ZHfont-Bold",
  bnd_goal_type_fontColor = "0xffffff",
  bnd_goal_type_fontSize = 14,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = -20,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 30,
  -- Time
  bnd_goal_time_fontFace = "$Ligue1",
  bnd_goal_time_fontColor = "0xffffff",
  bnd_goal_time_fontSize = 14,
  bnd_goal_time_alignV = "CENTER",
  bnd_goal_time_alignH = "CENTER",
  bnd_goal_time_top = -7,
  bnd_goal_time_bottom = 0,
  bnd_goal_time_left = 0,
  bnd_goal_time_right = -150
}
France2Info = {
  bnd_fontFace = "$Ligue1",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x02FFCE",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 65,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xffffff",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 30,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x1F1F1F",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x1F1F1F",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 80,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "RIGHT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 50,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 20
}
GermanyInfo = {
  bnd_fontFace = "$CruyffSansExpandes",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_background = {
    name = "$BackroundGoal",  
    id = 3  
 },
  bnd_background_alignV = "CENTER",
  bnd_background_alignH = "LEFT",
  bnd_background_width = 320,
  bnd_background_height = 320,  
  bnd_background_top = 10,
  bnd_background_left = 20,   
  -- Avatar
  bnd_bg_avatar_color_alpha = 0,
  bnd_bg_avatar_color = "0x00E675",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_width = 110,
  bnd_goal_player_avatar_height = 110,
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 40,
  bnd_goal_player_avatar_left = 255,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 27,
  bnd_team_crest_height = 27,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 38,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 10,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 17,
  bnd_goal_player_name_alignV = "BOTTOM",
  bnd_goal_player_name_alignH = "LEFT",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = -15,
  bnd_goal_player_name_left = 85,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 0,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "CENTER",
  bnd_goal_player_level_top = -100,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 100,
  -- Count
  bnd_goal_player_count_fontColor = "0xffffff",
  bnd_goal_player_count_fontSize = 14,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "CENTER",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = -30,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xffffff",
  bnd_goal_player_desc_fontSize = 17,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = -45,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 90,
  -- Type
  bnd_goal_type_fontFace = "$ZHfont-Bold",
  bnd_goal_type_fontColor = "0xffffff",
  bnd_goal_type_fontSize = 14,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 90,
  -- Time
  bnd_goal_time_fontFace = "$CruyffSansExpandes",
  bnd_goal_time_fontColor = "0xffffff",
  bnd_goal_time_fontSize = 14,
  bnd_goal_time_alignV = "CENTER",
  bnd_goal_time_alignH = "CENTER",
  bnd_goal_time_top = -45,
  bnd_goal_time_bottom = 0,
  bnd_goal_time_left = 0,
  bnd_goal_time_right = -30
}
IndonesiaInfo = {
  bnd_fontFace = "$Liga1",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "CENTER",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 0,
  -- Background
  bnd_bg1_color = "0x00519D",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xFFFFFF",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x505050",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 15,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x505050",
  bnd_bg_crest_color_alpha = 1,
  bnd_team_crest_width = 60,
  bnd_team_crest_height = 60,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 20,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,  
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 0,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0xFFFFFF",
  bnd_goal_player_count_fontSize = 13,
  bnd_goal_player_count_alignV = "TOP",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 1,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 30,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 10,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 0
}
ItalyInfo = {
  bnd_text_bold = false,	
  bnd_fontFace = "$SerieA",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_background = {
    name = "$BackroundGoal",  
    id = 5
 },
  bnd_background_alignV = "CENTER",
  bnd_background_alignH = "LEFT",
  bnd_background_width = 250,
  bnd_background_height = 250,  
  bnd_background_top = -50,
  bnd_background_left = 20,   
  -- Avatar
  bnd_bg_avatar_color_alpha = 0,
  bnd_bg_avatar_color = "0x00E675",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_width = 90,
  bnd_goal_player_avatar_height = 90,
  bnd_goal_player_avatar_top = 10,
  bnd_goal_player_avatar_bottom = 70,
  bnd_goal_player_avatar_left = 83,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 25,
  bnd_team_crest_height = 25,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = -97,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 45,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xc82727",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 100,
  bnd_goal_team_name_left = 160,
  bnd_goal_team_name_right = 0,      
  -- Name
  bnd_goal_player_name_fontColor = "0x59E7EB",
  bnd_goal_player_name_fontSize = 12,
  bnd_goal_player_name_alignV = "BOTTOM",
  bnd_goal_player_name_alignH = "LEFT",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 90,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x59E7EB",
  bnd_goal_player_level_fontSize = 35,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "CENTER",
  bnd_goal_player_level_top = -20,
  bnd_goal_player_level_bottom = -10,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 60,
  -- Count
  bnd_goal_player_count_fontColor = "0x083C65",
  bnd_goal_player_count_fontSize = 15,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "CENTER",
  bnd_goal_player_count_top = -20,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = -20,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x083C65",
  bnd_goal_player_desc_fontSize = 17,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 70,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = -35,
  -- Type
  bnd_goal_type_fontColor = "0x083C65",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = -35,
  -- Time
  bnd_goal_time_fontFace = "$SerieA",
  bnd_goal_time_fontColor = "0x083C65",  
  bnd_goal_time_fontSize = 14,
  bnd_goal_time_alignV = "CENTER",
  bnd_goal_time_alignH = "CENTER",
  bnd_goal_time_top = -90,
  bnd_goal_time_bottom = 0,
  bnd_goal_time_left = 0,
  bnd_goal_time_right = -20
}
JapanInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 485,
  bnd_eventinfo_left = 60,
  -- Background
  bnd_bg1_color = "0xFFFFFF",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x000000",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 30,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x000000",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 40,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x000000",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 21,
  bnd_goal_player_name_bottom = 0,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 19,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 15,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 80,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 18,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 15,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 10,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 18,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "LEFT",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 15,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0
}
LeagueOneEflInfo = {   
  bnd_forceCaps = true,
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_bg1_color = "0xffffff",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 360,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 10,
  
  bnd_bg2_color = "0x1AFE68",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 360,
  bnd_bg2_color_height = 25,
  bnd_bg2_color_left = 10,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = -14,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 14,
  bnd_goal_player_name_left = 20,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 14,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 230,
  -- Count
  bnd_goal_player_count_fontColor = "0xF5F5F5",
  bnd_goal_player_count_fontSize = 0,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 15,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x461648",
  bnd_goal_player_desc_fontSize = 0,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x461648",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = -3,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0,
  -- Logo
  bnd_logo = {
    name = "$LeagueLogo",
    id = 60
  },  
  bnd_logo_color = "0x1AFE68",
  bnd_logo_color_top = 0,
  bnd_logo_color_bottom = 0,
  bnd_logo_alignV = "CENTER",
  bnd_logo_alignH = "LEFT",
  bnd_logo_width = 70,
  bnd_logo_height = 70,
  bnd_logo_top = 0,
  bnd_logo_bottom = 0,
  bnd_logo_left = -70,
  bnd_logo_right = 0
}
SaudiArabiaInfo = {
  bnd_fontFace = "$SPL",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0xFFFFFF",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x4B4B4B",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x4B4B4B",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 20,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x4B4B4B",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 21,
  bnd_goal_player_name_bottom = 0,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 19,
  -- Count
  bnd_goal_player_count_fontColor = "0x151515",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 15,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 80,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x151515",
  bnd_goal_player_desc_fontSize = 10,
  bnd_goal_player_desc_alignV = "TOP",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 3,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x151515",
  bnd_goal_type_fontSize = 18,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 15,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 15
}
SpainInfo = {
  bnd_fontFace = "$LaLiga",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_background = {
    name = "$BackroundGoal",  
    id = 4
 },
  bnd_background_alignV = "CENTER",
  bnd_background_alignH = "LEFT",
  bnd_background_width = 320,
  bnd_background_height = 320,  
  bnd_background_top = 10,
  bnd_background_left = 20,   
  -- Avatar
  bnd_bg_avatar_color_alpha = 0,
  bnd_bg_avatar_color = "0x00E675",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_width = 110,
  bnd_goal_player_avatar_height = 110,
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 15,
  bnd_goal_player_avatar_left = 50,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 27,
  bnd_team_crest_height = 27,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = -70,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 1000000000000000000000,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 20,
  bnd_team1_crest_right = 0,
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 17,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 160,
  bnd_goal_team_name_right = 0,  
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 25,
  bnd_goal_player_name_alignV = "BOTTOM",
  bnd_goal_player_name_alignH = "LEFT",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 60,
  bnd_goal_player_name_left = 160,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontFace = "$LaLiga_Light",
  bnd_goal_player_level_fontColor = "0xEA3B52",
  bnd_goal_player_level_fontSize = 70,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "CENTER",
  bnd_goal_player_level_top = 7,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = -20,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 15,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "CENTER",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 10,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = -95,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xEA3B52",
  bnd_goal_player_desc_fontSize = 17,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = -45,
  bnd_goal_player_desc_bottom = 20,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = -110,
  -- Type
  bnd_goal_type_fontFace = "$LaLiga",
  bnd_goal_type_fontColor = "0xEA3B52",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 30,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = -107,
  -- Time
  bnd_goal_time_fontFace = "$LaLiga",
  bnd_goal_time_fontColor = "0x000000",
  bnd_goal_time_fontSize = 15,
  bnd_goal_time_alignV = "CENTER",
  bnd_goal_time_alignH = "CENTER",
  bnd_goal_time_top = -45,
  bnd_goal_time_bottom = 0,
  bnd_goal_time_left = 0,
  bnd_goal_time_right = -95
}
Spain2Info = {
  bnd_fontFace = "$LaLiga",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x151515",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xF5F5F5",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x04D4D4",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 28,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xFF5C41",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xF5F5F5",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xF5F5F5",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
LigaFInfo = {
  bnd_forceCaps = true,
  bnd_fontFace = "$DINPro-CondBold", 
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x09BFBA",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x1e1e1e",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x2C6ADB",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 30,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x151515",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x151515",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x151515",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0xFFFFFF",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xFFFFFF",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0xFFFFFF",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
MalaysiaInfo = { 
  bnd_forceCaps = true,
  bnd_fontFace = "$Malaysia",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x001763",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x0004DF",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x16FEC2",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x0004DF",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 80,
  -- Count
  bnd_goal_player_count_fontColor = "0x16FEC2",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x16FEC2",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "RIGHT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 50,
  -- Type
  bnd_goal_type_fontColor = "0x16FEC2",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 20
}
NetherlandsInfo = { 
  bnd_fontFace = "$Eredivisie",
    -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x5C5C5C",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xffffff",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x5C5C5C",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x5C5C5C",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 80,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "RIGHT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 50,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 20
}
PegadaianLiga2Info = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "CENTER",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 0,
  -- Background
  bnd_bg1_color = "0x07472B",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xAED328",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0xAED328",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 15,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xAED328",
  bnd_bg_crest_color_alpha = 1,
  bnd_team_crest_width = 60,
  bnd_team_crest_height = 60,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 20,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 0,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0xFFFFFF",
  bnd_goal_player_count_fontSize = 13,
  bnd_goal_player_count_alignV = "TOP",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 1,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 30,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x07472B",
  bnd_goal_player_desc_fontSize = 10,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x07472B",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 0
}
SwitzerlandInfo = {
  bnd_forceCaps = true,
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_bg1_color = "0xffffff",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 360,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 10,
  
  bnd_bg2_color = "0x1AFE68",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 360,
  bnd_bg2_color_height = 25,
  bnd_bg2_color_left = 10,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = -14,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 14,
  bnd_goal_player_name_left = 20,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 14,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 230,
  -- Count
  bnd_goal_player_count_fontColor = "0xF5F5F5",
  bnd_goal_player_count_fontSize = 0,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 15,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x461648",
  bnd_goal_player_desc_fontSize = 0,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x461648",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = -3,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0,
  -- Logo
  bnd_logo = {
    name = "$LeagueLogo",
    id = 189
  },  
  bnd_logo_color = "0x1AFE68",
  bnd_logo_color_top = -5,
  bnd_logo_color_bottom = 0,
  bnd_logo_alignV = "CENTER",
  bnd_logo_alignH = "LEFT",
  bnd_logo_width = 70,
  bnd_logo_height = 65.2,
  bnd_logo_top = 3,
  bnd_logo_bottom = 0,
  bnd_logo_left = -70,
  bnd_logo_right = 0,
}
ThailandInfo = {
  bnd_forceCaps = true,
  bnd_fontFace = "$DINPro-CondBold", 
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0xCECECE",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x000000",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0xFE0000",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xFE0000",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 80,
  -- Count
  bnd_goal_player_count_fontColor = "0xffffff",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xffffff",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "RIGHT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 50,
  -- Type
  bnd_goal_type_fontColor = "0xffffff",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 20
}
UefaInfo = {
  bnd_forceCaps = true,   
  bnd_fontFace = "$UCL-Regular", 
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x08187D",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xFFFFFF",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x040D46",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 15,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x040D46",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 0,
  bnd_team_crest_height = 0,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 20,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 10,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 0
}
UefaUelInfo = {
  bnd_forceCaps = true,   
  bnd_fontFace = "$DINPro-CondBold",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 90,
  -- Background
  bnd_bg1_color = "0x000000",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xE14711",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x000000",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 40,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x474BE5",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 21,
  bnd_goal_player_name_bottom = 0,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 19,
  -- Count
  bnd_goal_player_count_fontColor = "0xFFFFFF",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 15,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 80,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xFFFFFF",
  bnd_goal_player_desc_fontSize = 18,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 15,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 10,
  -- Type
  bnd_goal_type_fontColor = "0xFFFFFF",
  bnd_goal_type_fontSize = 18,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "LEFT",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 15,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0
}
UefaWomensInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x012652",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x0657A0",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0xFFFFFF",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 15,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xFFFFFF",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 0,
  bnd_team_crest_height = 0,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 20,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 15,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0xFFFFFF",
  bnd_goal_player_count_fontSize = 40,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 18,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 8,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xFFFFFF",
  bnd_goal_player_desc_fontSize = 10,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0xFFFFFF",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 0
}
VietnamInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x8E1026",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xDEDEDE",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x3C3C3C",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x3C3C3C",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 80,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "RIGHT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 50,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 20
}
WomensSuperLeagueInfo = {
  bnd_forceCaps = true, 
  bnd_fontFace = "$Epl",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x1D0F33",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xf5f5f5",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x1D0F33",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x1D0F33",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 80,
  -- Count
  bnd_goal_player_count_fontColor = "0x1D0F33",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x1D0F33",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "RIGHT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 50,
  -- Type
  bnd_goal_type_fontColor = "0x1D0F33",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 20
}
-------------------------------------
-- Eveninfo Turnamen --
-------------------------------------
WorldCupInfo = {
  bnd_fontFace = "$Qatar2022Arabic",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x240211",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x02C7B3",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x000000",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 28,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x240211",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
PialaIndonesiaInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x3471B2",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xD8DF3A",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 28,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xffffff",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
WorldCupWomensInfo = {
  bnd_fontFace = "$FWWC2023Bold",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x275759",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xF4F4DC",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x000000",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 28,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xffffff",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0x275759",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x275759",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x275759",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
FaCupInfo = {
  bnd_fontFace = "$Emirates-Bold",
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0xA8222A",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xffffff",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x3E3E3B",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 28,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xffffff",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
UefaEuropeInfo = {
 -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 90,
  -- Background
  bnd_bg1_color = "0x000000",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x00BF0C",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x000000",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 40,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x474BE5",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 21,
  bnd_goal_player_name_bottom = 0,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 19,
  -- Count
  bnd_goal_player_count_fontColor = "0xFFFFFF",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 15,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 80,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xFFFFFF",
  bnd_goal_player_desc_fontSize = 18,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 15,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 10,
  -- Type
  bnd_goal_type_fontColor = "0xFFFFFF",
  bnd_goal_type_fontSize = 18,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "LEFT",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 15,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0
}
AsianCupInfo = {
  bnd_forceCaps = true,
  bnd_fontFace = "$DINPro-CondBold", 
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x2D065F",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x94DF2A",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0xCEC0D7",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 30,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xCEC0D7",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0x2D065F",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x2D065F",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x2D065F",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
KingSaudiCupInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x17573B",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xFBDE98",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x000000",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 30,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x000000",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
EuroCupInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x1B38D2",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xffffff",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x1B38D2",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 30,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xffffff",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
UsaOpenCupInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0xD5093A",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x1A2237",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 30,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xffffff",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0xffffff",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xffffff",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0xffffff",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
CopaDelReyInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0xE60035",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x1F1831",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 30,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xffffff",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0xffffff",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xffffff",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0xffffff",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
AfricaCupInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x004530",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 350,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xFF7900",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x726C6C",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 30,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x726C6C",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "LEFT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 80,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xffffff",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 15,
  bnd_goal_player_name_left = 25,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0xffffff",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 15,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 20,
  -- Count
  bnd_goal_player_count_fontColor = "0xffffff",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 18,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 19,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xffffff",
  bnd_goal_player_desc_fontSize = 15,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 20,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 20,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0xffffff",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = 0,
  bnd_goal_type_left = 25,
  bnd_goal_type_right = 0
}
CoppaItaliaInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 485,
  bnd_eventinfo_left = 60,
  -- Background
  bnd_bg1_color = "0xFFFFFF",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xAA2C1D",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 30,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0xAA2C1D",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 40,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xAA2C1D",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 21,
  bnd_goal_player_name_bottom = 0,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 19,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 15,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 80,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 18,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 15,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 10,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 18,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "LEFT",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 15,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0
}
DfbPokalInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 485,
  bnd_eventinfo_left = 60,
  -- Background
  bnd_bg1_color = "0x05BB6A",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xD2D7D1",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 30,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 40,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xffffff",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 21,
  bnd_goal_player_name_bottom = 0,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 19,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 15,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 80,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 18,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 15,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 10,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 18,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "LEFT",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 15,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0
}
CoupeDeFranceInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 485,
  bnd_eventinfo_left = 60,
  -- Background
  bnd_bg1_color = "0x071A31",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x1A8EC4",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 30,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0xffffff",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 40,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0xffffff",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 21,
  bnd_goal_player_name_bottom = 0,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 19,
  -- Count
  bnd_goal_player_count_fontColor = "0xffffff",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 15,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 80,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xffffff",
  bnd_goal_player_desc_fontSize = 18,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 15,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 10,
  -- Type
  bnd_goal_type_fontColor = "0xffffff",
  bnd_goal_type_fontSize = 18,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "LEFT",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 15,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0
}
FcwcInfo = {
  bnd_forceCaps = true,
  bnd_fontFace = "$CruyffSans-Medium", 
  bnd_forceCaps = true,
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 80,
  -- Background
  bnd_bg1_color = "0xffffff",
  bnd_bg1_color_alignH = "CENTER",
  bnd_bg1_color_width = 360,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 10,
  
  bnd_bg2_color = "0x000000",
  bnd_bg2_color_alignH = "CENTER",
  bnd_bg2_color_width = 360,
  bnd_bg2_color_height = 25,
  bnd_bg2_color_left = 10,
  -- Avatar
  bnd_bg_avatar_color = "0xD0950B",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 0,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = -14,
  bnd_team_crest_bottom = 0,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = 0,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 0,
  bnd_goal_player_name_bottom = 14,
  bnd_goal_player_name_left = 20,
  bnd_goal_player_name_right = 0,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 0,
  bnd_goal_player_level_bottom = 14,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 230,
  -- Count
  bnd_goal_player_count_fontColor = "0xF5F5F5",
  bnd_goal_player_count_fontSize = 0,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 0,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 15,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x461648",
  bnd_goal_player_desc_fontSize = 0,
  bnd_goal_player_desc_alignV = "BOTTOM",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 2,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0xFFFFFF",
  bnd_goal_type_fontSize = 15,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 20,
  bnd_goal_type_bottom = -3,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0,
  -- Logo
  bnd_logo = {
    name = "$LeagueLogo",
    id = "CupID18"
  },  
  bnd_logo_color = "0x000000",
  bnd_logo_color_top = -5,
  bnd_logo_color_bottom = 0,
  bnd_logo_alignV = "CENTER",
  bnd_logo_alignH = "LEFT",
  bnd_logo_width = 70,
  bnd_logo_height = 65.2,
  bnd_logo_top = 3,
  bnd_logo_bottom = 0,
  bnd_logo_left = -70,
  bnd_logo_right = 0,
}
CopaLibertadoresInfo = {
  -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 485,
  bnd_eventinfo_left = 60,
  -- Background
  bnd_bg1_color = "0xEDC261",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0x986B2A",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 30,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x000000",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 40,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x000000",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x000000",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 21,
  bnd_goal_player_name_bottom = 0,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0x000000",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 19,
  -- Count
  bnd_goal_player_count_fontColor = "0x000000",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 15,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 80,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0x000000",
  bnd_goal_player_desc_fontSize = 18,
  bnd_goal_player_desc_alignV = "CENTER",
  bnd_goal_player_desc_alignH = "CENTER",
  bnd_goal_player_desc_top = 0,
  bnd_goal_player_desc_bottom = 15,
  bnd_goal_player_desc_left = 0,
  bnd_goal_player_desc_right = 10,
  -- Type
  bnd_goal_type_fontColor = "0x000000",
  bnd_goal_type_fontSize = 18,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "LEFT",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 15,
  bnd_goal_type_left = 20,
  bnd_goal_type_right = 0
}
UefaNationsInfo = { 
  bnd_fontFace = "$UEFANations-Bold",
 -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x253242",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xF9FDFD",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x253242",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 20,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x253242",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0x253242",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 21,
  bnd_goal_player_name_bottom = 0,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0x253242",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 19,
  -- Count
  bnd_goal_player_count_fontColor = "0xF9FDFD",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 15,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 80,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xF9FDFD",
  bnd_goal_player_desc_fontSize = 10,
  bnd_goal_player_desc_alignV = "TOP",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 3,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0xF9FDFD",
  bnd_goal_type_fontSize = 18,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 15,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 15
}
CopaAmericaInfo = {
 -- Posisi
  bnd_eventinfo_alignV = "BOTTOM",
  bnd_eventinfo_alignH = "LEFT",
  bnd_eventinfo_bottom = 65,
  bnd_eventinfo_left = 100,
  -- Background
  bnd_bg1_color = "0x000000",
  bnd_bg1_color_alignH = "LEFT",
  bnd_bg1_color_width = 300,
  bnd_bg1_color_height = 45,
  bnd_bg1_color_left = 0,
  
  bnd_bg2_color = "0xB40309",
  bnd_bg2_color_alignH = "LEFT",
  bnd_bg2_color_width = 350,
  bnd_bg2_color_height = 28,
  bnd_bg2_color_left = 0,
  -- Avatar
  bnd_bg_avatar_color = "0x0C1D83",
  bnd_goal_player_avatar_alignV = "CENTER",
  bnd_goal_player_avatar_alignH = "LEFT",
  bnd_goal_player_avatar_top = 20,
  bnd_goal_player_avatar_bottom = 0,
  bnd_goal_player_avatar_left = 0,
  bnd_goal_player_avatar_right = 0,
  -- Crest
  bnd_bg_crest_color = "0x0C1D83",
  bnd_bg_crest_color_alpha = 0,
  bnd_team_crest_width = 35,
  bnd_team_crest_height = 35,
  bnd_team_crest_alignV = "CENTER",
  bnd_team_crest_alignH = "RIGHT",
  bnd_team_crest_top = 0,
  bnd_team_crest_bottom = 15,
  bnd_team_crest_left = 0,
  bnd_team_crest_right = -10,
  -- Crest1
  bnd_bg_crest1_color = "",
  bnd_bg_crest1_color_alpha = 0,
  bnd_team1_crest_width = 27,
  bnd_team1_crest_height = 27,
  bnd_team1_crest_alignV = "CENTER",
  bnd_team1_crest_alignH = "LEFT",
  bnd_team1_crest_top = -70,
  bnd_team1_crest_bottom = 0,
  bnd_team1_crest_left = 1000000000000000000000,
  bnd_team1_crest_right = 0,  
  -- TeamName
  bnd_goal_team_name_fontColor = "0xEA3B52",
  bnd_goal_team_name_fontSize = 0,
  bnd_goal_team_name_alignV = "BOTTOM",
  bnd_goal_team_name_alignH = "LEFT",
  bnd_goal_team_name_top = 0,
  bnd_goal_team_name_bottom = 90,
  bnd_goal_team_name_left = 153,
  bnd_goal_team_name_right = 0,    
  -- Name
  bnd_goal_player_name_fontColor = "0xFFFFFF",
  bnd_goal_player_name_fontSize = 18,
  bnd_goal_player_name_alignV = "CENTER",
  bnd_goal_player_name_alignH = "CENTER",
  bnd_goal_player_name_top = 21,
  bnd_goal_player_name_bottom = 0,
  bnd_goal_player_name_left = 0,
  bnd_goal_player_name_right = 20,
  -- Level
  bnd_goal_player_level_fontColor = "0xFFFFFF",
  bnd_goal_player_level_fontSize = 18,
  bnd_goal_player_level_alignV = "CENTER",
  bnd_goal_player_level_alignH = "RIGHT",
  bnd_goal_player_level_top = 20,
  bnd_goal_player_level_bottom = 0,
  bnd_goal_player_level_left = 0,
  bnd_goal_player_level_right = 19,
  -- Count
  bnd_goal_player_count_fontColor = "0xFFFFFF",
  bnd_goal_player_count_fontSize = 18,
  bnd_goal_player_count_alignV = "CENTER",
  bnd_goal_player_count_alignH = "RIGHT",
  bnd_goal_player_count_top = 0,
  bnd_goal_player_count_bottom = 15,
  bnd_goal_player_count_left = 0,
  bnd_goal_player_count_right = 80,
  -- PlayerDesc
  bnd_goal_player_desc_fontColor = "0xFFFFFF",
  bnd_goal_player_desc_fontSize = 10,
  bnd_goal_player_desc_alignV = "TOP",
  bnd_goal_player_desc_alignH = "LEFT",
  bnd_goal_player_desc_top = 3,
  bnd_goal_player_desc_bottom = 0,
  bnd_goal_player_desc_left = 10,
  bnd_goal_player_desc_right = 0,
  -- Type
  bnd_goal_type_fontColor = "0xFFFFFF",
  bnd_goal_type_fontSize = 18,
  bnd_goal_type_alignV = "CENTER",
  bnd_goal_type_alignH = "CENTER",
  bnd_goal_type_top = 0,
  bnd_goal_type_bottom = 15,
  bnd_goal_type_left = 0,
  bnd_goal_type_right = 15
}
function EventInfo:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.nationalization = 2
  o.services = {
    EventManagerService = o.api("EventManagerService"),
    SquadManagementService = o.api("SquadMgtService"),
    MatchInfoService = o.api("MatchInfoService"),
    TeamService = o.api("TeamService")
  }
  local HOMETEAM = 0
  local AWAYTEAM = 1
  
  o.TeamsData = o.services.MatchInfoService.GetMatchTeams()
  homeTeamlineupData = o.services.SquadManagementService.GetCurrentPlayerLineup(HOMETEAM, o.TeamsData[1].assetId, 0)
  awayTeamlineupData = o.services.SquadManagementService.GetCurrentPlayerLineup(AWAYTEAM, o.TeamsData[2].assetId, 0)
  
  local AlgeriaTeams = o.services.TeamService.GetTeams(leagueIDs.Algeria, 0, 0, true)
  local AfcTeams = o.services.TeamService.GetTeams(leagueIDs.Afc, 0, 0, true)
  local ArgentinaTeams = o.services.TeamService.GetTeams(leagueIDs.Argentina, 0, 0, true)
  local AsianCupU23Teams = o.services.TeamService.GetTeams(leagueIDs.AsianCupU23, 0, 0, true)
  local BelgiumTeams = o.services.TeamService.GetTeams(leagueIDs.Belgium, 0, 0, true)
  local BRILiga1Teams = o.services.TeamService.GetTeams(leagueIDs.BRILiga1, 0, 0, true)
  local BrazilTeams = o.services.TeamService.GetTeams(leagueIDs.Brazil, 0, 0, true)
  local ClassicTeams = o.services.TeamService.GetTeams(leagueIDs.Classic, 0, 0, true)
  local Classic2Teams = o.services.TeamService.GetTeams(leagueIDs.Classic2, 0, 0, true)
  local ChampionshipEflTeams = o.services.TeamService.GetTeams(leagueIDs.ChampionshipEfl, 0, 0, true)
  local DenmarkTeams = o.services.TeamService.GetTeams(leagueIDs.Denmark, 0, 0, true)
  local D1ArkemaTeams = o.services.TeamService.GetTeams(leagueIDs.D1Arkema, 0, 0, true)
  local EcuadorTeams = o.services.TeamService.GetTeams(leagueIDs.Ecuador, 0, 0, true)
  local EgyptTeams = o.services.TeamService.GetTeams(leagueIDs.Egypt, 0, 0, true)
  local EnglandTeams = o.services.TeamService.GetTeams(leagueIDs.England, 0, 0, true)
  local FranceTeams = o.services.TeamService.GetTeams(leagueIDs.France, 0, 0, true)
  local France2Teams = o.services.TeamService.GetTeams(leagueIDs.France2, 0, 0, true)
  local GermanyTeams = o.services.TeamService.GetTeams(leagueIDs.Germany, 0, 0, true)
  local Germany2Teams = o.services.TeamService.GetTeams(leagueIDs.Germany2, 0, 0, true)
  local IndonesiaTeams = o.services.TeamService.GetTeams(leagueIDs.Indonesia, 0, 0, true)
  local InternationalTeams = o.services.TeamService.GetTeams(leagueIDs.International, 0, 0, true)
  local International2Teams = o.services.TeamService.GetTeams(leagueIDs.International2, 0, 0, true)
  local ItalyTeams = o.services.TeamService.GetTeams(leagueIDs.Italy, 0, 0, true)
  local JapanTeams = o.services.TeamService.GetTeams(leagueIDs.Japan, 0, 0, true)
  local KoreaRepublicTeams = o.services.TeamService.GetTeams(leagueIDs.KoreaRepublic, 0, 0, true)
  local LeagueOneEflTeams = o.services.TeamService.GetTeams(leagueIDs.LeagueOneEfl, 0, 0, true)
  local LigaFTeams = o.services.TeamService.GetTeams(leagueIDs.LigaF, 0, 0, true)
  local MalaysiaTeams = o.services.TeamService.GetTeams(leagueIDs.Malaysia, 0, 0, true)
  local MexicoTeams = o.services.TeamService.GetTeams(leagueIDs.Mexico, 0, 0, true)
  local MoroccoTeams = o.services.TeamService.GetTeams(leagueIDs.Morocco, 0, 0, true)
  local NetherlandsTeams = o.services.TeamService.GetTeams(leagueIDs.Netherlands, 0, 0, true)
  local PegadaianLiga2Teams = o.services.TeamService.GetTeams(leagueIDs.PegadaianLiga2, 0, 0, true)
  local PortugalTeams = o.services.TeamService.GetTeams(leagueIDs.Portugal, 0, 0, true)
  local RestOfWorldTeams = o.services.TeamService.GetTeams(leagueIDs.RestOfWorld, 0, 0, true)
  local RestOfWorld2Teams = o.services.TeamService.GetTeams(leagueIDs.RestOfWorld2, 0, 0, true)
  local RusiaTeams = o.services.TeamService.GetTeams(leagueIDs.Rusia, 0, 0, true)
  local SaudiArabiaTeams = o.services.TeamService.GetTeams(leagueIDs.SaudiArabia, 0, 0, true)
  local ScotlandTeams = o.services.TeamService.GetTeams(leagueIDs.Scotland, 0, 0, true)
  local SouthAfricaTeams = o.services.TeamService.GetTeams(leagueIDs.SouthAfrica, 0, 0, true)
  local SpainTeams = o.services.TeamService.GetTeams(leagueIDs.Spain, 0, 0, true)
  local Spain2Teams = o.services.TeamService.GetTeams(leagueIDs.Spain2, 0, 0, true)
  local SwedenTeams = o.services.TeamService.GetTeams(leagueIDs.Sweden, 0, 0, true)
  local SwitzerlandTeams = o.services.TeamService.GetTeams(leagueIDs.Switzerland, 0, 0, true)
  local ThailandTeams = o.services.TeamService.GetTeams(leagueIDs.Thailand, 0, 0, true)
  local TurkeyTeams = o.services.TeamService.GetTeams(leagueIDs.Turkey, 0, 0, true)
  local UefaTeams = o.services.TeamService.GetTeams(leagueIDs.Uefa, 0, 0, true)
  local UefaUelTeams = o.services.TeamService.GetTeams(leagueIDs.UefaUel, 0, 0, true)
  local UefaWomensTeams = o.services.TeamService.GetTeams(leagueIDs.UefaWomens, 0, 0, true)
  local UkraineTeams = o.services.TeamService.GetTeams(leagueIDs.Ukraine, 0, 0, true)
  local UnitedStatesTeams = o.services.TeamService.GetTeams(leagueIDs.UnitedStates, 0, 0, true)
  local USANWSLTeams = o.services.TeamService.GetTeams(leagueIDs.USANWSL, 0, 0, true)
  local VanaramaFootballLeagueTeams = o.services.TeamService.GetTeams(leagueIDs.VanaramaFootballLeague, 0, 0, true)
  local VietnamTeams = o.services.TeamService.GetTeams(leagueIDs.Vietnam, 0, 0, true)
  local WomensSuperLeagueTeams = o.services.TeamService.GetTeams(leagueIDs.WomensSuperLeague, 0, 0, true)
  
  
  o.handlerId = o.services.EventManagerService.RegisterHandler(function(...)
    o:handleEvent(...)
  end)
  
  o.currentdata = nil
  
  if currentCupData.cupIndex > 0 then
    if currentCupData.cupIndex == 1 then
      o.currentdata = UefaInfo
    elseif currentCupData.cupIndex == 2 then
      o.currentdata = WorldCupInfo
    elseif currentCupData.cupIndex == 3 then
      o.currentdata = UefaUelInfo
    elseif currentCupData.cupIndex == 4 then
      o.currentdata = PialaIndonesiaInfo
    elseif currentCupData.cupIndex == 5 then
      o.currentdata = WorldCupWomensInfo
    elseif currentCupData.cupIndex == 6 then
      o.currentdata = UefaWomensInfo
    elseif currentCupData.cupIndex == 7 then
      o.currentdata = FaCupInfo
    elseif currentCupData.cupIndex == 8 then
      o.currentdata = UefaEuropeInfo
     elseif currentCupData.cupIndex == 9 then
      o.currentdata = AsianCupInfo
    elseif currentCupData.cupIndex == 10 then
      o.currentdata = KingSaudiCupInfo
    elseif currentCupData.cupIndex == 11 then
      o.currentdata = EuroCupInfo
    elseif currentCupData.cupIndex == 12 then
      o.currentdata = UsaOpenCupInfo
    elseif currentCupData.cupIndex == 13 then
      o.currentdata = CopaAmericaInfo
    elseif currentCupData.cupIndex == 14 then
      o.currentdata = CopaDelReyInfo
    elseif currentCupData.cupIndex == 15 then
      o.currentdata = CoppaItaliaInfo
    elseif currentCupData.cupIndex == 16 then
      o.currentdata = DfbPokalInfo
    elseif currentCupData.cupIndex == 17 then
      o.currentdata = CoupeDeFranceInfo
    elseif currentCupData.cupIndex == 18 then
      o.currentdata = FcwcInfo
    elseif currentCupData.cupIndex == 19 then
      o.currentdata = CopaLibertadoresInfo
    elseif currentCupData.cupIndex == 20 then
      o.currentdata = UefaNationsInfo
    end
  else
     if o:isInTable(o.TeamsData[1], AlgeriaTeams) and o:isInTable(o.TeamsData[2], AlgeriaTeams) then
    o.currentdata = AlgeriaInfo
    elseif o:isInTable(o.TeamsData[1], AfcTeams) and o:isInTable(o.TeamsData[2], AfcTeams) then
    o.currentdata = AsianCupInfo
    elseif o:isInTable(o.TeamsData[1], ArgentinaTeams) and o:isInTable(o.TeamsData[2], ArgentinaTeams) then
     o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], BRILiga1Teams) and o:isInTable(o.TeamsData[2], BRILiga1Teams) then
      o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], AsianCupU23Teams) and o:isInTable(o.TeamsData[2], AsianCupU23Teams) then
     o.currentdata = AsianCupU23Info
    elseif o:isInTable(o.TeamsData[1], BelgiumTeams) and o:isInTable(o.TeamsData[2], BelgiumTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], BrazilTeams) and o:isInTable(o.TeamsData[2], BrazilTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], ClassicTeams) and o:isInTable(o.TeamsData[2], ClassicTeams) then
    o.currentdata = ClassicInfo
    elseif o:isInTable(o.TeamsData[1], Classic2Teams) and o:isInTable(o.TeamsData[2], Classic2Teams) then
    o.currentdata = ClassicInfo
    elseif o:isInTable(o.TeamsData[1], ChampionshipEflTeams) and o:isInTable(o.TeamsData[2], ChampionshipEflTeams) then
    o.currentdata = ChampionshipEflInfo
    elseif  o:isInTable(o.TeamsData[1], D1ArkemaTeams) and o:isInTable(o.TeamsData[2], D1ArkemaTeams) then
    o.currentdata = D1ArkemaInfo
    elseif  o:isInTable(o.TeamsData[1], DenmarkTeams) and o:isInTable(o.TeamsData[2], DenmarkTeams) then
    o.currentdata = DenmarkInfo
    elseif  o:isInTable(o.TeamsData[1], EcuadorTeams) and o:isInTable(o.TeamsData[2], EcuadorTeams) then
    o.currentdata = EcuadorInfo
    elseif  o:isInTable(o.TeamsData[1], EgyptTeams) and o:isInTable(o.TeamsData[2], EgyptTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], EnglandTeams) and o:isInTable(o.TeamsData[2], EnglandTeams) then
    o.currentdata = EnglandInfo
    o.currentdata.bnd_background.id = 1
    elseif o:isInTable(o.TeamsData[1], FranceTeams) and o:isInTable(o.TeamsData[2], FranceTeams) then
    o.currentdata = FranceInfo
    o.currentdata.bnd_background.id = 2
    elseif o:isInTable(o.TeamsData[1], France2Teams) and o:isInTable(o.TeamsData[2], France2Teams) then
    o.currentdata = France2Info
    elseif o:isInTable(o.TeamsData[1], GermanyTeams) and o:isInTable(o.TeamsData[2], GermanyTeams) then
    o.currentdata = GermanyInfo
    elseif o:isInTable(o.TeamsData[1], Germany2Teams) and o:isInTable(o.TeamsData[2], Germany2Teams) then
    o.currentdata = GermanyInfo
    elseif o:isInTable(o.TeamsData[1], IndonesiaTeams) and o:isInTable(o.TeamsData[2], IndonesiaTeams) then
    o.currentdata = IndonesiaInfo
    elseif o:isInTable(o.TeamsData[1], InternationalTeams) and o:isInTable(o.TeamsData[2], InternationalTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], International2Teams) and o:isInTable(o.TeamsData[2], International2Teams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], ItalyTeams) and o:isInTable(o.TeamsData[2], ItalyTeams) then
    o.currentdata = ItalyInfo
    elseif o:isInTable(o.TeamsData[1], JapanTeams) and o:isInTable(o.TeamsData[2], JapanTeams) then
    o.currentdata = JapanInfo
    elseif o:isInTable(o.TeamsData[1], KoreaRepublicTeams) and o:isInTable(o.TeamsData[2], KoreaRepublicTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], LeagueOneEflTeams) and o:isInTable(o.TeamsData[2], LeagueOneEflTeams) then
    o.currentdata = LeagueOneEflInfo
    elseif o:isInTable(o.TeamsData[1], LigaFTeams) and o:isInTable(o.TeamsData[2], LigaFTeams) then
    o.currentdata = LigaFInfo
    elseif o:isInTable(o.TeamsData[1], MalaysiaTeams) and o:isInTable(o.TeamsData[2], MalaysiaTeams) then
    o.currentdata = MalaysiaInfo
    elseif o:isInTable(o.TeamsData[1], MexicoTeams) and o:isInTable(o.TeamsData[2], MexicoTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], MoroccoTeams) and o:isInTable(o.TeamsData[2], MoroccoTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], NetherlandsTeams) and o:isInTable(o.TeamsData[2], NetherlandsTeams) then
    o.currentdata = NetherlandsInfo
    elseif o:isInTable(o.TeamsData[1], PegadaianLiga2Teams) and o:isInTable(o.TeamsData[2], PegadaianLiga2Teams) then
    o.currentdata = PegadaianLiga2Info
    elseif o:isInTable(o.TeamsData[1], PortugalTeams) and o:isInTable(o.TeamsData[2], PortugalTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], RestOfWorldTeams) and o:isInTable(o.TeamsData[2], RestOfWorldTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], RestOfWorld2Teams) and o:isInTable(o.TeamsData[2], RestOfWorld2Teams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], SaudiArabiaTeams) and o:isInTable(o.TeamsData[2], SaudiArabiaTeams) then
    o.currentdata = SaudiArabiaInfo
    elseif o:isInTable(o.TeamsData[1], ScotlandTeams) and o:isInTable(o.TeamsData[2], ScotlandTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], SouthAfricaTeams) and o:isInTable(o.TeamsData[2], SouthAfricaTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], SpainTeams) and o:isInTable(o.TeamsData[2], SpainTeams) then
    o.currentdata = SpainInfo
    elseif o:isInTable(o.TeamsData[1], Spain2Teams) and o:isInTable(o.TeamsData[2], Spain2Teams) then
    o.currentdata = Spain2Info
    elseif o:isInTable(o.TeamsData[1], SwitzerlandTeams) and o:isInTable(o.TeamsData[2], SwitzerlandTeams) then
    o.currentdata = SwitzerlandInfo
    elseif o:isInTable(o.TeamsData[1], ThailandTeams) and o:isInTable(o.TeamsData[2], ThailandTeams) then
    o.currentdata = ThailandInfo
    elseif o:isInTable(o.TeamsData[1], TurkeyTeams) and o:isInTable(o.TeamsData[2], TurkeyTeams) then
    o.currentdata = EAFCInfo
    o.currentdata.bnd_background.id = 0
    elseif o:isInTable(o.TeamsData[1], UefaTeams) and o:isInTable(o.TeamsData[2], UefaTeams) then
    o.currentdata = UefaInfo
    elseif o:isInTable(o.TeamsData[1], UefaUelTeams) and o:isInTable(o.TeamsData[2], UefaUelTeams) then
    o.currentdata = UefaUelInfo
    elseif o:isInTable(o.TeamsData[1], UefaWomensTeams) and o:isInTable(o.TeamsData[2], UefaWomensTeams) then
    o.currentdata = UefaWomensInfo
    elseif o:isInTable(o.TeamsData[1], UnitedStatesTeams) and o:isInTable(o.TeamsData[2], UnitedStatesTeams) then
    o.currentdata = IndonesiaInfo
    o.currentdata.bnd_bg_avatar_color = "0x1e1e1e"
    o.currentdata.bnd_bg1_color = "0x1e1e1e"
    elseif o:isInTable(o.TeamsData[1], USANWSLTeams) and o:isInTable(o.TeamsData[2], USANWSLTeams) then
    o.currentdata = IndonesiaInfo
    o.currentdata.bnd_bg_avatar_color = "0x1e1e1e"
    o.currentdata.bnd_bg1_color = "0x1e1e1e"
    elseif o:isInTable(o.TeamsData[1], VietnamTeams) and o:isInTable(o.TeamsData[2], VietnamTeams) then
    o.currentdata = VietnamInfo
    elseif o:isInTable(o.TeamsData[1], WomensSuperLeagueTeams) and o:isInTable(o.TeamsData[2], WomensSuperLeagueTeams) then
    o.currentdata = WomensSuperLeagueInfo
  else 
    o.currentdata = EAFCInfo
  end
  end
  
  o.isinitialized = 0
  
  local facts = o:getMatchFacts()
  nowHomeScore = facts[1].data.value + 0
  nowAwayScore = facts[1].data.valueRight + 0

  teamCrest = {
    name = "$Crest",
    id = 0
  }
  team1Crest = {
    name = "$LaLigaTeamCrest",
    id = 0
  }
  playerAvatar = {
    name = "$Head",
    id = 0
  }
  
o.im.Subscribe(BND_NATIONALIZATION, function()
  end)
  o.im.Subscribe(BND_VISIBLE, function()
    o.im.Publish(BND_VISIBLE, false)
  end)
  o.im.Subscribe("bnd_player_visible", function()
    o.im.Publish("bnd_player_visible", false)
  end)
  o.im.Subscribe(BND_ALPHA, function()
  end)
  o.im.Subscribe(BND_DATA, function()
  end)
  o.im.Subscribe("bnd_text", function()
  end)
  o.im.Subscribe("bnd_team_crest", function()
  end)
  o.im.Subscribe("bnd_team1_crest", function()
  end)
  o.im.Subscribe("bnd_goal_player_avatar", function()
  end)
  o.im.Subscribe("bnd_goal_player_name", function()
  end)
  o.im.Subscribe("bnd_goal_team_name", function()
  end)
  o.im.Subscribe("bnd_goal_player_level", function()
  end)
  o.im.Subscribe("bnd_goal_player_count", function()
  end)
  o.im.Subscribe("bnd_goal_player_desc", function()
  end)
  o.im.Subscribe("bnd_goal_time", function()
  end)
  o.im.Subscribe("bnd_goal_type", function()
  end)
  o.im.Subscribe("bnd_goal_desc", function()
  end)
  
    for k,v in pairs(o.currentdata) do
    o.im.Subscribe(k, function()
      o.im.Publish(k, v)
    end)
  end
  
  return o
end

function EventInfo:handleEvent(eventType, data)
  if eventType == EventTypes.OverlayTypeIngameCardInjury then
    self:updateEventInfo(data.subtype, data.hideshow, data.subtypestr, data.msg)
  end
  if eventType == EventTypes.OverlayTypeGoal then
    self:updateGoalScored(data.subtype, data.hideshow, data.subtypestr, data.msg)
  end
end

function EventInfo:updateEventInfo(subtype, hideshow, subtypestr, msg)
  local params = OverlayParam.split(msg, "|")
  if hideshow == "SHOW" then
    if initialized == false then
      self.im.Publish(BND_NATIONALIZATION, self.nationalization)
      initialized = true
    end
    if params and table.getn(params) > 0 then
      self.im.Publish(BND_VISIBLE, true)
      local bottomText = ""
      local showBottomText = false
      if #params == 7 then
        bottomText = params[7]
        showBottomText = true
      end
      local eventInfo = {
        team = params[3],
        kitNumber = params[5],
        playerName = params[6],
        bottomText = bottomText,
        showBottomText = showBottomText,
        iconType = params[4] + 0
      }
      teamCrest.id = params[2] + 0
      team1Crest.id = params[2] + 0
      self.im.Publish("bnd_team_crest", teamCrest)
      self.im.Publish("bnd_team1_crest", team1Crest)   
      self.im.Publish("bnd_goal_team_name", params[2])
      self.im.Publish("bnd_goal_time", params[7])

      -- Ambil info pemain (untuk foto/avatar)
      local playerName = params[6]
      local teamside = 0 -- Asumsikan 0 (home) atau ubah logikanya kalau perlu
      local playerInfo = self:getPlayerInfo(teamside, teamCrest.id, playerName)
      playerAvatar.id = playerInfo.assetId

      -- Tampilkan avatar pemain
      self.im.Publish("bnd_goal_player_avatar", playerAvatar)
      if playerInfo.assetId == 0 then
        self.im.Publish("bnd_player_visible", false)
      else
        self.im.Publish("bnd_player_visible", true)
      end

      local eventdesc = ""
      local eventtype = params[4] + 0
      if eventtype == 0 then 
        eventdesc = "Injured"
      elseif eventtype == 1 then
        eventdesc = "Yellow Card"
      elseif eventtype == 2 then
        eventdesc = "Red Card"
      elseif eventtype == 3 then
        eventdesc = "Red Card"
      end

      self.im.Publish("bnd_goal_time", params[7])
      self.im.Publish("bnd_goal_team_name", params[2])
      self.im.Publish("bnd_goal_type", eventdesc)
      self.im.Publish("bnd_goal_player_level", params[5])
      self.im.Publish("bnd_goal_player_name", string.gsub(playerInfo.playerName, "%b()", " ")) -- Nama rapi

      self.im.Publish(BND_DATA, eventInfo)
    end
  elseif hideshow == "UPDATE" then
    self.im.Publish(BND_ALPHA, params[1] / 100)
  else
    self.im.Publish(BND_VISIBLE, false)
    self.im.Publish("bnd_player_visible", false)
  end
end

function EventInfo:addDaysToDate(dateStr, daysToAdd)
    local d, m, y = dateStr:match("(%d%d)/(%d%d)/(%d%d)")
    local timestamp = os.time({ day = tonumber(d), month = tonumber(m), year = 2000 + tonumber(y) })  
    local newTimestamp = timestamp + (daysToAdd * 86400)
    local newDate = os.date("%d/%m/%y", newTimestamp)  
    return newDate
end

function EventInfo:updateGoalScored(subtype, hideshow, subtypestr, msg)
  if hideshow ~= "HIDE" then
    if initialized == false then
      self.im.Publish(BND_NATIONALIZATION, self.nationalization)
      initialized = true
    end
    local params = OverlayParam.split(msg, "|")
    local teamside
    if params and table.getn(params) > 0 then
      self.isinitialized = self.isinitialized + 1
      
      if self.isinitialized == 1 then
        beforeHomeScore = nowHomeScore
        beforeAwayScore = nowAwayScore
      end

      local bottomText = ""
      local showBottomText = false
      local goalScored = {
        kitNumber = "",
        bottomText = bottomText,
        showBottomText = showBottomText,
        iconType = params[13] + 0,
        playerName = params[14],
        team = params[15]
      }

      nowHomeScore = params[5] + 0
      nowAwayScore = params[6] + 0
      local isOg = string.find(goalScored.playerName, "(OG)")
      local isPenalty = string.find(goalScored.playerName, "(Pen)")
      local currentTime = string.gsub(params[7], "%'", " ")

      if nowHomeScore > beforeHomeScore then
        teamCrest.id = params[1] + 0
        team1Crest.id = params[1] + 0
        teamside = 0
        if isOg then 
          teamCrest.id = params[3] + 0
        end
      elseif nowAwayScore > beforeAwayScore then
        teamCrest.id = params[3] + 0
        team1Crest.id = params[3] + 0
        teamside = 1
        if isOg then 
          teamCrest.id = params[1] + 0
          team1Crest.id = params[1] + 0
        end
      end
      
      self.im.Publish("bnd_team_crest", teamCrest)
      self.im.Publish("bnd_team1_crest", team1Crest)

      if currentTime + 0 > 90 then
        self.im.Publish("bnd_goal_player_desc", " ")
      else
        self.im.Publish("bnd_goal_player_desc", goalDesc)
      end

      local playerName = goalScored.playerName
      local playerInfo = self:getPlayerInfo(teamside, teamCrest.id, playerName, isOg)
      playerAvatar.id = playerInfo.assetId

      if self.isinitialized == 1 then
        if goalStatistics[playerInfo.assetId] then
          goalStatistics[playerInfo.assetId] = goalStatistics[playerInfo.assetId] + 1
        else
          goalStatistics[playerInfo.assetId] = 1
        end

        if not GOALS then
          GOALS = {}
        end
        if not GOALS[playerInfo.assetId] then
          GOALS[playerInfo.assetId] = 0
        end
        GOALS[playerInfo.assetId] = GOALS[playerInfo.assetId] + 1
      end

      local goalDesc = ""
      if goalStatistics[playerInfo.assetId] == 1 then
        goalDesc = "Shots"
      elseif goalStatistics[playerInfo.assetId] == 2 then
        goalDesc = "Brace"
      elseif goalStatistics[playerInfo.assetId] == 3 then
        goalDesc = "HatTrick"
      elseif goalStatistics[playerInfo.assetId] == 4 then
        goalDesc = "BigFour"
      elseif goalStatistics[playerInfo.assetId] == 5 then
        goalDesc = "PalmTrick"
      elseif goalStatistics[playerInfo.assetId] > 5 then
        goalDesc = "SuperHero"
      end

      local goalType = ""
      if isOg then 
        goalType = "GOAL OG"
      elseif isPenalty then
        goalType = "PENALTY"
      else
        goalType = "GOALS"
      end

      -- 🟩 FIX: Nama tim sesuai sisi (home/away)
-- Tentukan nama tim sesuai side, aman untuk home & away
-- Ambil teamName dari params[2] (full name) sesuai side
local teamName = ""
if teamside == 0 then
    teamName = params[2] or "HOME"   -- home team full name
else
    teamName = params[4] or "AWAY"   -- away team full name
end

-- Publish overlay
self.im.Publish("bnd_goal_player_name", string.gsub(playerInfo.playerName, "%b()", " "))
self.im.Publish("bnd_goal_player_avatar", playerAvatar)
self.im.Publish("bnd_goal_team_name", teamName)
self.im.Publish("bnd_goal_player_level", ""..playerInfo.level)

      if currentTime + 0 > 90 then
        self.im.Publish("bnd_goal_player_desc", " ")
      else
        self.im.Publish("bnd_goal_player_desc", goalDesc)
      end

      self.im.Publish("bnd_goal_time", params[7])
      self.im.Publish("bnd_goal_type", goalType)
      self.im.Publish("bnd_goal_player_count", "'"..goalStatistics[playerInfo.assetId])

      self.im.Publish(BND_VISIBLE, true)
      if playerInfo.assetId == 0 then
        self.im.Publish("bnd_player_visible", false)
      else
        self.im.Publish("bnd_player_visible", true)
      end

      self.im.Publish(BND_DATA, goalScored)
    end
  else
    self.im.Publish(BND_VISIBLE, false)
    self.im.Publish("bnd_player_visible", false)
    if self.isinitialized >= 2 then
      self.isinitialized = 0
    end
  end
end

function EventInfo:split(str, delimiter)
  local index = {}
  local oid = {}
  for k = 1,string.len(str) do
    if string.sub(str,k,k) == delimiter then
      table.insert(index,k)
    end
  end

  table.insert(oid,string.sub(str,1,index[1]-1))
  for k=1,#index-1 do
    table.insert(oid,string.sub(str,index[k]+1,index[k+1]-1))
  end
  table.insert(oid,string.sub(str,index[#index]+1,string.len(str)))
  return oid
end

function EventInfo:getPlayerInfo(teamSide, teamID, playername, isOg)
  local count = 0
  local specialString = false
  local playerInfo = {
    assetId = 0,
    level = 0,
    playerName = playername
  }
  local teamlineupData = nil
  if isOg then 
    if teamSide == 0 then
       teamSide = 1
    else
       teamSide = 0
    end
  end
  
  if teamSide == 0 then
    teamlineupData = homeTeamlineupData
  else
    teamlineupData = awayTeamlineupData
  end
  if string.find(playername, "-") or string.find(playername, "%.") then
    specialString = true
  end
 
  if specialString == false then
    count = 0
    playerInfo.playerName =  string.gsub(playername, "%b()", " ")
    playerInfo.playerName =  string.gsub(playerInfo.playerName, "^%s*(.-)%s*$", "%1")
  end
  
  for _FORV_6_ = 1, table.getn(teamlineupData) do
    if specialString == true then
       if string.find(playername, teamlineupData[_FORV_6_].playerName,1,true) then 
        if count == 0 then
          count = count + 1
          playerInfo.assetId = teamlineupData[_FORV_6_].CARD_ID
          playerInfo.level = teamlineupData[_FORV_6_].jerseyNumber
          playerInfo.playerName = teamlineupData[_FORV_6_].playerName
        end
      end
    else
      if string.find(playerInfo.playerName, teamlineupData[_FORV_6_].playerName,1,true) and playerInfo.playerName == teamlineupData[_FORV_6_].playerName then
        if count == 0 then
          count = count + 1
          playerInfo.assetId = teamlineupData[_FORV_6_].CARD_ID
          playerInfo.level = teamlineupData[_FORV_6_].jerseyNumber
          playerInfo.playerName = teamlineupData[_FORV_6_].playerName
        end
      end
    end
  end
  return playerInfo
end

function EventInfo:k_include(tab, value)
  for k,v in pairs(tab) do
    if k == value then
        return true
    end
  end
  return false
end

function EventInfo:isInTable(value, tbl) 
  for i = 1, #tbl do
    if tbl[i].id == value.assetId then
      return true
    end
  end
  return false
end

function EventInfo:getMatchFacts()
  local facts = self.services.MatchInfoService.GetMatchFacts(true)
  local o = facts.homeData
  for i, v in ipairs(o) do
    v.data.valueRight = facts.awayData[i].data.value
  end
  return o
end

function EventInfo:finalize()
  self.im.Unsubscribe(BND_VISIBLE)
  self.im.Unsubscribe(BND_ALPHA)
  self.im.Unsubscribe(BND_DATA)
  self.im.Unsubscribe(BND_NATIONALIZATION)
  self.im.Unsubscribe("bnd_text")
  self.im.Unsubscribe("bnd_team_crest")
  self.im.Unsubscribe("bnd_team1_crest")
  self.im.Unsubscribe("bnd_goal_player_avatar")
  self.im.Unsubscribe("bnd_goal_player_name")
  self.im.Unsubscribe("bnd_goal_team_name")
  self.im.Unsubscribe("bnd_goal_player_level")
  self.im.Unsubscribe("bnd_goal_player_desc")
  self.im.Unsubscribe("bnd_goal_player_count")
  self.im.Unsubscribe("bnd_player_visible")
  self.im.Unsubscribe("bnd_goal_time")
  self.im.Unsubscribe("bnd_goal_type")
  self.im.Unsubscribe("bnd_goal_desc")
  for k,v in pairs(EAFCInfo) do
    self.im.Unsubscribe(k)
  end
  self.services.EventManagerService.UnregisterHandler(self.handlerId)
end

return EventInfo

-- Thanks : Ma'ruf Id & Laosiji --
-- And All Modder --
-- EventInfo All League ( @mvnprodreal ) --